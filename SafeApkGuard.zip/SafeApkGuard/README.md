# Safe Apk Guard — Android ilova (1-bosqich, serversiz)

Telegram botdagi (`apkbot.py`) xavf qoidalarining telefon varianti. Hamma tahlil telefonning o‘zida bajariladi.

## Imkoniyatlar
- **Ulashish orqali tekshirish:** Telegramda APK faylni bosing → «Ulashish» → Safe Apk Guard (yoki havolani ulashing).
  Fayl vaqtinchalik nusxalanib tahlil qilinadi va darhol o‘chiriladi.
- **O‘rnatilgan ilovalarni skanerlash:** ruxsatlar, hozir YOQILGAN Accessibility/bildirishnoma/administrator xizmatlari,
  qayerdan o‘rnatilgani (Play Market — ishonch; Telegramdan fayl — xavf belgisi).
- **Yangi ilovani tekshirish:** fon tekshiruvi (har 15 daqiqa) va ixtiyoriy «Real vaqtda himoya» xizmati.
- **Havola tekshiruvi:** soxta bank/davlat domenlari, APK havolalar, IP, punycode, qisqartirilgan havolalarni ochish.

## Ishga tushirish
1. Android Studio (Ladybug 2024.2 yoki yangi) da `SafeApkGuard` papkasini oching → Gradle sinxronlanadi
   (`gradle-wrapper.properties` bor, Studio Gradle 8.9 ni o‘zi yuklaydi).
2. Telefonni ulang (USB debugging) → **Run ▶**.
3. Versiyalar eskirgan bo‘lsa, Studio yangilashni taklif qiladi (AGP, Kotlin, Compose BOM) — rozi bo‘ling.

## Bilishingiz kerak
- `QUERY_ALL_PACKAGES` ruxsati Play Market’da alohida asoslashni talab qiladi. Dastlab APK sifatida tarqating.
- Android boshqa ilovalar (Telegram) xabarlarini o‘qishga ruxsat bermaydi — ilova chatni emas, telefonni himoya qiladi.
- Bu bosqichda VirusTotal YO‘Q (kalitni APK ichida saqlab bo‘lmaydi). Keyingi bosqich: bot serveriga kichik API
  (hash bo‘yicha so‘rov + umumiy qora ro‘yxat) qo‘shib, ilovani shunga ulash.

## Tuzilma
- `analysis/` — ball tizimi (`Scoring`), APK tahlili (`ApkAnalyzer`), o‘rnatilgan ilovalar (`AppScanner`), havolalar (`LinkAnalyzer`)
- `ShareActivity` — «Ulashish» oynasi · `MainActivity`/`Ui.kt` — asosiy ekran
- `NewAppChecker` (WorkManager) · `GuardService` (real vaqt) · `Notifier`
