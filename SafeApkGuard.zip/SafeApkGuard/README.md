# Safe Apk Guard — Android ilova (1-bosqich, serversiz)

Telegram botdagi (`apkbot.py`) xavf qoidalarining telefon varianti. Hamma tahlil telefonning o‘zida bajariladi.

## 0.4.0
- Tuzatishlar: «O‘chirish» tugmasi (REQUEST_DELETE_PACKAGES ruxsati), Play Market bloki (to‘liq ko‘rinish, bosishni tutish, «Bekor qilish»,
  Sozlamalarda diagnostika qatori), taqiqlangan ilova baribir o‘rnatilsa o‘chirish oynasi avtomatik ochiladi.
- Login/coin/admin qismi olib tashlandi (kerak bo‘lsa keyin qo‘shiladi). Bloklangan ilovalar ro‘yxati bepul, faqat telefonda saqlanadi.

## Bloklangan ilovalar
Sozlamalar → «Bloklangan ilovalar»: foydalanuvchi ilova nomini yozadi, nom ro‘yxatdan olib tashlanmaguncha o‘rnatib bo‘lmaydi.
- Tizim o‘rnatuvchi oynasida nom ko‘rinsa — «Bekor qilish» bosiladi (APK fayl qayerdan kelganidan qat’i nazar).
- Play Market va boshqa do‘konlarda nom + «O‘rnatish» tugmasi ko‘rinsa — do‘kondan chiqarib yuboriladi.
- Baribir o‘rnatilib qolsa (masalan, boshqa qurilmadan masofaviy o‘rnatish) — bildirishnoma, bosilsa o‘chirish oynasi ochiladi.
- Cheklov: Android ilovaga «o‘rnatishni taqiqlash» huquqini bermaydi, shuning uchun bu ekranni kuzatish orqali ishlaydi;
  do‘kon dizayni/tili o‘zgarsa mos kelmasligi mumkin. «O‘rnatishdan himoya» (Accessibility) yoqilgan bo‘lishi shart.

## 0.3.0 da nima yangi
- **Havola tekshiruvi tuzatildi:** ishonchli domen (github.com kabi) APK havolani endi «xavfsiz» qila olmaydi; qisqa havola ochilmasa
  «tekshirib bo‘lmadi» deb ogohlantiradi; `payment…`, `gov.uk`, `olx.pl` kabi to‘g‘ri saytlar yolg‘on xavfli bo‘lmaydi; matndagi
  BARCHA havolalar tekshiriladi; kirill/lookalike (punycode) domenlar, `payme.uz@evil.com` hiylasi, IP havolalar ushlanadi.
- **«Ishonchli ilovalar» ro‘yxati:** bloklangan oynada ham, ilovalar ro‘yxatida ham «Ishonchli deb belgilash»; Sozlamalarda boshqariladi.
- Standart rejim endi «faqat xavfli» (1). Yangi APK tushishi bilan oldindan tahlil (o‘rnatish oynasi ochilganda natija tayyor).
- Ilova yangilanganda real vaqt xizmati o‘zi qayta ishga tushadi. Oppo/Realme/OnePlus o‘rnatuvchisi (`com.oplus.appdetail`) qo‘shildi.
- Tekshiruv tarixi, natijani ulashish, xotira skanerida progress va bekor qilish, batareya/avto-ishga tushirish yo‘riqnomasi.
- **Til:** o‘zbekcha kirill (`values-b+uz+Cyrl`). R8 (minify) yoqildi — muammo bo‘lsa `build.gradle.kts` da `isMinifyEnabled = false` qiling.

## Imkoniyatlar
- **Ulashish orqali tekshirish:** Telegramda APK faylni bosing → «Ulashish» → Safe Apk Guard (yoki havolani ulashing).
  Fayl vaqtinchalik nusxalanib tahlil qilinadi va darhol o‘chiriladi.
- **O‘rnatilgan ilovalarni skanerlash:** ruxsatlar, hozir YOQILGAN Accessibility/bildirishnoma/administrator xizmatlari,
  qayerdan o‘rnatilgani (Play Market — ishonch; Telegramdan fayl — xavf belgisi).
- **Yangi ilovani tekshirish:** fon tekshiruvi (har 15 daqiqa) va ixtiyoriy «Real vaqtda himoya» xizmati.
- **Havola tekshiruvi:** soxta bank/davlat domenlari, APK havolalar, IP, punycode, qisqartirilgan havolalarni ochish.

## O‘rnatishdan himoya (yangi)
- Sozlamalar → «O‘rnatishdan himoya»: **Maxsus imkoniyatlar** xizmatini va **Barcha fayllarga kirish**ni yoqing.
- Xizmat FAQAT tizim o‘rnatuvchi oynasini kuzatadi (`res/xml/install_guard_config.xml` → `packageNames`).
- Telegramdan yuklangan APK fayl papkadan topilib tahlil qilinadi; o‘rnatish oynasidagi ilova nomi mos kelsa va
  rejimga ko‘ra xavfli bo‘lsa, «Bekor qilish» tugmasi bosiladi.
- Android 13+: «Cheklangan sozlama» chiqsa → Ilova ma’lumoti → ⋮ → «Cheklangan sozlamalarga ruxsat berish».
- Bog‘lanish havolalari va donat rekvizitlari `Config.kt` da.

## Ishga tushirish
1. Android Studio (Ladybug 2024.2 yoki yangi) da `SafeApkGuard` papkasini oching → Gradle sinxronlanadi
   (`gradle-wrapper.properties` bor, Studio Gradle 8.9 ni o‘zi yuklaydi).
2. Telefonni ulang (USB debugging) → **Run ▶**.
3. Versiyalar eskirgan bo‘lsa, Studio yangilashni taklif qiladi (AGP, Kotlin, Compose BOM) — rozi bo‘ling.

## Bilishingiz kerak
- `QUERY_ALL_PACKAGES` ruxsati Play Market’da alohida asoslashni talab qiladi. Dastlab APK sifatida tarqating.
- Android boshqa ilovalar (Telegram) xabarlarini o‘qishga ruxsat bermaydi — ilova chatni emas, telefonni himoya qiladi.
- Bu bosqichda VirusTotal YO‘Q (kalitni APK ichida saqlab bo‘lmaydi). Keyingi bosqich: bot serveriga kichik API
  (hash bo‘yicha so‘rov + umumiy qora ro‘yxat) qo‘shib, ilovani shunga ulash.

## Tuzilma
- `analysis/` — ball tizimi (`Scoring`), APK tahlili (`ApkAnalyzer`), o‘rnatilgan ilovalar (`AppScanner`), havolalar (`LinkAnalyzer`)
- `ShareActivity` — «Ulashish» oynasi · `MainActivity`/`Ui.kt` — asosiy ekran
- `NewAppChecker` (WorkManager) · `GuardService` (real vaqt) · `Notifier`

## GitHub'da doimiy imzo bilan yig'ish
Repozitoriy → Settings → Secrets and variables → Actions → New repository secret:
- `KEYSTORE_BASE64` — `KEYSTORE_BASE64.txt` fayl ichidagi matn (to'liq)
- `KEYSTORE_PASSWORD` — kalit paroli
Shundan keyin har yig'ish bir xil imzo bilan chiqadi va yangi versiya eskisining ustiga o'rnatiladi.
Kalit faylni (`release.jks`) hech qachon repozitoriyga yuklamang.
