# O‘z kodimiz to‘liq saqlanadi (xizmatlar, aktivitilar, enum Flag/Level, Compose lambdalar).
-keep class uz.safeapk.guard.** { *; }
