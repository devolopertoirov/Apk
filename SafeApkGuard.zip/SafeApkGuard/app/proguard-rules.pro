# Maxsus qoidalar kerak emas.
