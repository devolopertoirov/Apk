package uz.safeapk.guard

import android.content.Context
import android.os.Environment
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import uz.safeapk.guard.analysis.ApkAnalyzer
import uz.safeapk.guard.analysis.ScanResult

data class StoredApk(val file: File, val sizeBytes: Long, val result: ScanResult)

/** Telefon xotirasidagi APK fayllarni topib tahlil qiladi («Xotira tekshiruvi»). */
object StorageScan {
    private val EXT = listOf(".apk", ".apks", ".xapk", ".apkm")
    private val SKIP = listOf("/Android/data", "/Android/obb", "/.thumbnails", "/.Trash", "/.trash")

    suspend fun scan(ctx: Context, onProgress: (Int, Int) -> Unit = { _, _ -> }): List<StoredApk> = withContext(Dispatchers.IO) {
        if (!InstallGuard.hasFileAccess(ctx)) return@withContext emptyList()
        val found = ArrayList<File>()
        Environment.getExternalStorageDirectory().walkTopDown().maxDepth(7)
            .onEnter { d -> SKIP.none { d.path.contains(it) } }
            .forEach { f ->
                ensureActive()
                if (found.size < 300 && f.isFile && EXT.any { f.name.lowercase().endsWith(it) }) found += f
            }
        val total = found.size
        var done = 0
        found.mapNotNull { f ->
            ensureActive()
            val item = runCatching { StoredApk(f, f.length(), ApkAnalyzer.analyzeAny(ctx, f, null)) }.getOrNull()
            done++
            onProgress(done, total)
            item
        }.sortedWith(compareByDescending<StoredApk> { it.result.score }.thenBy { it.file.name.lowercase() })
    }
}
