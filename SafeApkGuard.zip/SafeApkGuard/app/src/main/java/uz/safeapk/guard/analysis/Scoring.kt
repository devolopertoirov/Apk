package uz.safeapk.guard.analysis

import androidx.annotation.StringRes
import uz.safeapk.guard.R

enum class Level { OK, WARN, BAD }

/** Xavf belgilari. Ballar Telegram botdagi (apkbot.py) qoidalar bilan bir xil. */
enum class Flag(val score: Int, @StringRes val reason: Int) {
    SMS_READ(25, R.string.r_sms_read),
    SMS_SEND(10, R.string.r_sms_send),
    ACCESS(30, R.string.r_access),
    DEVADMIN(20, R.string.r_devadmin),
    NOTIF(20, R.string.r_notif),
    INSTALL(8, R.string.r_install),
    OVERLAY(8, R.string.r_overlay),
    CALLLOG(8, R.string.r_calllog),
    TG(25, R.string.r_tg),
    PAYLOAD(30, R.string.r_payload),
    DEBUG(10, R.string.r_debug),
    BROKEN(15, R.string.r_broken),
    BOMB(30, R.string.r_bomb),
    COMBO(20, R.string.r_combo),
    SIDELOADED(10, R.string.r_sideloaded),
    FROM_TELEGRAM(20, R.string.r_from_telegram),
    ACTIVE_ACCESS(25, R.string.r_active_access),
    ACTIVE_NOTIF(15, R.string.r_active_notif),
    ACTIVE_ADMIN(15, R.string.r_active_admin),
}

data class ScanResult(
    val level: Level,
    val score: Int,
    val flags: List<Flag>,
    val packageName: String?,
    val label: String?,
    val sha256: String?,
    val validApk: Boolean = true,
)

object Scoring {
    const val BAD = 60
    const val WARN = 25

    fun build(
        flags: Set<Flag>, adjust: Int, pkg: String?, label: String?, sha: String?, valid: Boolean = true,
    ): ScanResult {
        val all = flags.toMutableSet()
        val strong = all.any {
            it == Flag.ACCESS || it == Flag.NOTIF || it == Flag.TG || it == Flag.DEVADMIN ||
                it == Flag.ACTIVE_ACCESS || it == Flag.ACTIVE_NOTIF
        }
        if ((Flag.SMS_READ in all && strong) || (Flag.ACCESS in all && Flag.OVERLAY in all)) {
            all += Flag.COMBO
        }
        val score = (all.sumOf { it.score } + adjust).coerceIn(0, 100)
        val level = when {
            score >= BAD -> Level.BAD
            score >= WARN -> Level.WARN
            else -> Level.OK
        }
        return ScanResult(level, score, all.sortedByDescending { it.score }, pkg, label, sha, valid)
    }
}
