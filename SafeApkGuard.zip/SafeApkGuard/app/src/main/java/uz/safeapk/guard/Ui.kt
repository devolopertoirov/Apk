package uz.safeapk.guard

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.safeapk.guard.analysis.Level

val GreenOk = Color(0xFF1B7F4B)
val AmberWarn = Color(0xFFB26A00)
val RedBad = Color(0xFFC62828)

fun levelColor(l: Level) = when (l) {
    Level.OK -> GreenOk
    Level.WARN -> AmberWarn
    Level.BAD -> RedBad
}

@Composable
fun levelLabel(l: Level) = androidx.compose.ui.res.stringResource(
    when (l) {
        Level.OK -> R.string.level_ok
        Level.WARN -> R.string.level_warn
        Level.BAD -> R.string.level_bad
    }
)

@Composable
fun GuardTheme(mode: Int? = null, content: @Composable () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val m = mode ?: androidx.compose.runtime.remember { Prefs(ctx).theme }
    val dark = when (m) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF6FD6A0)) else lightColorScheme(primary = GreenOk),
        content = content,
    )
}

@Composable
fun LevelIcon(level: Level, size: Int = 28) {
    Icon(
        imageVector = when (level) {
            Level.OK -> Icons.Filled.CheckCircle
            Level.WARN -> Icons.Filled.Info
            Level.BAD -> Icons.Filled.Warning
        },
        contentDescription = null,
        tint = levelColor(level),
        modifier = Modifier.size(size.dp),
    )
}

/** Fayl yoki havola tekshiruvi natijasi kartasi (asosiy ekranda va «Ulashish» oynasida ishlatiladi). */
@Composable
fun VerdictCard(v: Verdict, modifier: Modifier = Modifier) {
    val c = levelColor(v.level)
    val ctx = LocalContext.current
    val shareLabel = androidx.compose.ui.res.stringResource(R.string.btn_share_report)
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = c.copy(alpha = 0.10f)),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LevelIcon(v.level, 32)
                Spacer(Modifier.width(10.dp))
                Text(v.title, color = c, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            v.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            if (v.meta.isNotEmpty()) Spacer(Modifier.height(4.dp))
            v.meta.forEach { (k, value) ->
                Row {
                    Text("$k: ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                    Text(
                        value, style = MaterialTheme.typography.bodySmall,
                        fontFamily = if (k == "SHA-256") FontFamily.Monospace else FontFamily.Default,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(v.note, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = {
                val body = buildString {
                    appendLine(v.title)
                    v.reasons.forEach { appendLine("• $it") }
                    v.meta.forEach { (k, value) -> appendLine("$k: $value") }
                    append(v.note)
                }
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body)
                runCatching {
                    ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Text(shareLabel) }
        }
    }
}
