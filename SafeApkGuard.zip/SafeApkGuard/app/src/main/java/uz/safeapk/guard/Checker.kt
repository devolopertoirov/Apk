package uz.safeapk.guard

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import uz.safeapk.guard.analysis.ApkAnalyzer
import uz.safeapk.guard.analysis.Level
import uz.safeapk.guard.analysis.LinkAnalyzer
import uz.safeapk.guard.analysis.LinkResult
import uz.safeapk.guard.analysis.ScanResult

/** Ekranga chiqariladigan tayyor natija. */
data class Verdict(
    val level: Level,
    val title: String,
    val reasons: List<String>,
    val meta: List<Pair<String, String>>,
    val note: String,
)

object Verdicts {
    private fun note(ctx: Context, level: Level) = ctx.getString(
        when (level) {
            Level.BAD -> R.string.note_bad
            Level.WARN -> R.string.note_warn
            Level.OK -> R.string.note_ok
        }
    )

    fun fromScan(ctx: Context, r: ScanResult, fileName: String?): Verdict {
        val title = ctx.getString(
            when (r.level) {
                Level.BAD -> R.string.title_bad_file
                Level.WARN -> R.string.title_warn_file
                Level.OK -> R.string.title_ok_file
            }
        )
        val reasons = mutableListOf<String>()
        if (!r.validApk) reasons += ctx.getString(R.string.not_apk)
        reasons += r.flags.take(6).map { ctx.getString(it.reason) }
        val meta = mutableListOf<Pair<String, String>>()
        fileName?.let { meta += ctx.getString(R.string.meta_file) to it }
        r.label?.takeIf { it.isNotBlank() && it != r.packageName }?.let { meta += ctx.getString(R.string.app_name) to it }
        r.packageName?.let { meta += ctx.getString(R.string.meta_package) to it }
        r.sha256?.let { meta += ctx.getString(R.string.meta_sha) to it }
        return Verdict(r.level, title, reasons, meta, note(ctx, r.level))
    }

    fun fromLink(ctx: Context, r: LinkResult): Verdict {
        val title = ctx.getString(
            when (r.level) {
                Level.BAD -> R.string.title_bad_link
                Level.WARN -> R.string.title_warn_link
                Level.OK -> R.string.title_ok_link
            }
        )
        val meta = mutableListOf(ctx.getString(R.string.meta_host) to r.host)
        if (r.finalUrl != r.url) meta += "→" to r.finalUrl
        return Verdict(r.level, title, r.keys.map { ctx.getString(it.reason) }, meta, note(ctx, r.level))
    }
}

object Checker {
    private const val MAX_BYTES = 300L * 1024 * 1024

    private fun displayName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment

    /** Faylni vaqtinchalik nusxalab (hash bilan) tahlil qiladi, so‘ng nusxani o‘chiradi. */
    suspend fun checkUri(ctx: Context, uri: Uri): Verdict = withContext(Dispatchers.IO) {
        val name = displayName(ctx, uri)
        val tmp = File(ctx.cacheDir, "scan_${System.nanoTime()}.apk")
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("faylni ochib bo‘lmadi")
            input.use { src ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        md.update(buf, 0, n)
                        out.write(buf, 0, n)
                        total += n
                        if (total > MAX_BYTES) throw IOException("fayl juda katta")
                    }
                }
            }
            val sha = md.digest().joinToString("") { "%02x".format(it) }
            Verdicts.fromScan(ctx, ApkAnalyzer.analyzeFile(ctx, tmp, sha), name)
        } finally {
            tmp.delete()
        }
    }

    /** Matndagi birinchi havolani tekshiradi; havola topilmasa null. */
    suspend fun checkText(ctx: Context, text: String): Verdict? {
        val url = LinkAnalyzer.extractUrls(text).firstOrNull() ?: return null
        val r = LinkAnalyzer.inspect(url) ?: return null
        return Verdicts.fromLink(ctx, r)
    }
}
