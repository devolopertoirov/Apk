package uz.safeapk.guard

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Ilova tilini qo‘lda tanlash (auto = telefon tili; uz-Cyrl = o‘zbekcha kirill). Activity'lar attachBaseContext orqali ishlatadi. */
object Lang {
    fun wrap(base: Context): Context {
        val code = Prefs(base).lang
        if (code == "auto") return base
        val loc = if ('-' in code) Locale.forLanguageTag(code) else Locale(code)
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        return base.createConfigurationContext(cfg)
    }
}
