package uz.safeapk.guard

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.fragment.app.FragmentActivity

/** Safe Apk Guard ni o‘chirishga urinilganda ochiladi: PIN yoki barmoq izi to‘g‘ri bo‘lsa, 2 daqiqa ruxsat beriladi. */
class AuthActivity : FragmentActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GuardTheme {
                Surface(Modifier.fillMaxSize()) {
                    PinGate(title = stringResource(R.string.pin_uninstall_title), allowBiometric = true) {
                        Lock.allowUninstallFor(Prefs(this@AuthActivity), 120_000L)
                        Toast.makeText(this@AuthActivity, R.string.pin_uninstall_ok, Toast.LENGTH_LONG).show()
                        finish()
                    }
                }
            }
        }
    }
}
