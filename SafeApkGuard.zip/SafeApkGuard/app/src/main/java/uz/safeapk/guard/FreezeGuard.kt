package uz.safeapk.guard

import android.content.Context
import android.content.Intent
import android.telecom.TelecomManager

/**
 * «Muzlatish»: foydalanuvchi tanlagan ilova ochilganda oq ekran ko‘rsatiladi (FreezeActivity), xuddi ilova
 * ishlamayotgandek. Ilova ro‘yxatdan olib tashlanguncha (Sozlamalar, PIN talab qiladi) shunday davom etadi.
 *
 * Ishlash tamoyili: real vaqtda ekranga hech narsa yozilmaydi va hech narsa o‘chirilmaydi — xizmat faqat
 * taqiqlangan paket oldinga chiqqanini ko‘radi (Accessibility) va ustiga bo‘sh oq ekranni ochadi.
 */
object FreezeGuard {
    /** Muzlatib bo‘lmaydigan paketlar: o‘zimiz, uy ekrani, qo‘ng‘iroq va asosiy tizim ilovalari. */
    fun protectedPackages(ctx: Context): Set<String> {
        val out = linkedSetOf(
            ctx.packageName, "com.android.settings", "com.android.systemui", "com.android.phone",
            "android", "com.google.android.packageinstaller", "com.android.packageinstaller",
        )
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { out += it }
        }
        runCatching {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            tm?.defaultDialerPackage?.let { out += it }
        }
        return out
    }

    fun canFreeze(ctx: Context, pkg: String): Boolean = pkg.isNotBlank() && pkg !in protectedPackages(ctx)
}
