package uz.safeapk.guard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ota-ona: ekran vaqti cheklovi ro‘yxati (cheklangan ilova ochilganda oq ekran chiqadi). */
@Composable
fun RestrictedAppsSection() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var set by remember { mutableStateOf(prefs.restrictedApps) }
    var picking by remember { mutableStateOf(false) }
    val guard = rememberPinGuard()
    val labels = remember(set) { set.associateWith { ScreenTime.labelOf(ctx, it) } }

    if (picking) {
        AppPickerDialog(exclude = set, onDismiss = { picking = false }) { pkg ->
            prefs.restrictedApps = prefs.restrictedApps + pkg
            set = prefs.restrictedApps
            picking = false
        }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.screen_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.screen_desc), style = MaterialTheme.typography.bodySmall)
            if (set.isEmpty()) {
                Text(stringResource(R.string.screen_empty), style = MaterialTheme.typography.bodySmall)
            }
            set.sortedBy { (labels[it] ?: it).lowercase() }.forEach { pkg ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(labels[pkg] ?: pkg, fontWeight = FontWeight.SemiBold)
                        Text(pkg, style = MaterialTheme.typography.labelSmall)
                    }
                    // Cheklovni yechish PIN bilan himoyalangan (PIN o‘rnatilgan bo‘lsa)
                    TextButton(onClick = {
                        guard {
                            prefs.restrictedApps = prefs.restrictedApps - pkg
                            set = prefs.restrictedApps
                        }
                    }) { Text(stringResource(R.string.blocklist_remove)) }
                }
            }
            OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.screen_add))
            }
            if (set.isNotEmpty() && !InstallGuard.isAccessibilityOn(ctx)) {
                Text(stringResource(R.string.screen_need_access), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(stringResource(R.string.screen_tip), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun AppPickerDialog(exclude: Set<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val apps by produceState<List<Pair<String, String>>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { ScreenTime.launchableApps(ctx) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.screen_pick_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.screen_search)) },
                )
                val list = apps
                if (list == null) {
                    Text(stringResource(R.string.screen_loading), style = MaterialTheme.typography.bodySmall)
                } else {
                    val shown = list.filter { (label, pkg) ->
                        pkg !in exclude && (query.isBlank() || label.contains(query, ignoreCase = true) || pkg.contains(query, ignoreCase = true))
                    }
                    LazyColumn(Modifier.height(360.dp)) {
                        items(shown) { (label, pkg) ->
                            Column(Modifier.fillMaxWidth().clickable { onPick(pkg) }.padding(vertical = 8.dp)) {
                                Text(label, fontWeight = FontWeight.SemiBold)
                                Text(pkg, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.btn_cancel)) } },
    )
}
