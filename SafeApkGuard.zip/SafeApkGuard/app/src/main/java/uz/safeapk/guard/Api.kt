package uz.safeapk.guard

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Bot serveri (guardapi.py) bilan oddiy HTTPS/JSON aloqa. Qo‘shimcha kutubxona kerak emas. */
object Api {
    class ApiError(val code: String, val extra: JSONObject? = null) : Exception(code)

    fun base(ctx: Context): String {
        val custom = Prefs(ctx).apiBase.trim().trimEnd('/')
        return if (custom.isNotEmpty()) custom else Config.API_BASE.trim().trimEnd('/')
    }

    suspend fun call(
        ctx: Context, method: String, path: String, body: JSONObject? = null, auth: Boolean = true,
    ): JSONObject = withContext(Dispatchers.IO) {
        val b = base(ctx)
        if (!b.startsWith("https://")) throw ApiError("no_server")
        val conn = try {
            URL(b + path).openConnection() as HttpURLConnection
        } catch (e: Exception) {
            throw ApiError("no_server")
        }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("ngrok-skip-browser-warning", "1")
            if (auth) {
                val t = Prefs(ctx).token
                if (t.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $t")
            }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                throw ApiError("bad_response")
            }
            if (!json.optBoolean("ok", false)) throw ApiError(json.optString("error", "server"), json)
            json
        } catch (e: ApiError) {
            throw e
        } catch (e: IOException) {
            throw ApiError("network")
        } finally {
            conn.disconnect()
        }
    }
}
