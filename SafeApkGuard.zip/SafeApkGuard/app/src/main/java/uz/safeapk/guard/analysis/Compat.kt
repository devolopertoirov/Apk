package uz.safeapk.guard.analysis

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Android versiyalari orasidagi farqlarni yashiradi (API 33 da PackageInfoFlags paydo bo‘lgan). */
@Suppress("DEPRECATION")
object Compat {
    fun archiveInfo(pm: PackageManager, path: String, flags: Int): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageArchiveInfo(path, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            pm.getPackageArchiveInfo(path, flags)
        }
    } catch (e: Exception) {
        null
    }

    fun packageInfo(pm: PackageManager, pkg: String, flags: Int): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            pm.getPackageInfo(pkg, flags)
        }
    } catch (e: Exception) {
        null
    }

    fun installedApps(pm: PackageManager): List<ApplicationInfo> = try {
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            pm.getInstalledApplications(0)
        }
    } catch (e: Exception) {
        emptyList()
    }
}
