package uz.safeapk.guard

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.safeapk.guard.analysis.ApkAnalyzer
import uz.safeapk.guard.analysis.Level
import uz.safeapk.guard.analysis.ScanResult

/** Holat va ruxsatlarni tekshiruvchi yordamchilar (Sozlamalar ekrani uchun). */
object InstallGuard {
    /** Xizmat tizimga ulangan va ishlayaptimi (qulagan xizmat bu ro‘yxatda bo‘lmaydi). */
    fun isAccessibilityOn(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            val si = it.resolveInfo?.serviceInfo
            si != null && si.packageName == ctx.packageName && si.name == InstallGuardService::class.java.name
        }
    }

    /** Sozlamalarda yoqilgan (lekin qulagan bo‘lishi mumkin). */
    fun isEnabledInSettings(ctx: Context): Boolean {
        val me = ComponentName(ctx, InstallGuardService::class.java)
        return Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            .orEmpty().split(':').mapNotNull { ComponentName.unflattenFromString(it) }.any { it == me }
    }

    fun hasFileAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

private val APOSTROPHES = Regex("[‘’ʻʼ`´]")

/** Matnni solishtirish uchun: kichik harf va barcha apostrof turlari bitta ko‘rinishda. */
fun normText(s: String) = s.lowercase().replace(APOSTROPHES, "'")

/** Yaqinda yuklangan APK fayl va uning tahlili. */
class Candidate(
    val file: File, val label: String, val pkg: String, val result: ScanResult,
    val modified: Long, val fromTelegram: Boolean,
) {
    /** O‘rnatish oynasidagi matnlarda shu ilova nomi yoki paketi bormi. */
    fun matches(texts: List<String>): Boolean {
        val l = normText(label)
        val p = pkg.lowercase()
        return (l.length >= 3 && texts.any { it.contains(l) }) || (p.isNotEmpty() && texts.any { it.contains(p) })
    }
}

object RecentApks {
    private const val RECENT_MS = 30 * 60_000L
    private val APK_EXT = listOf(".apk", ".apks", ".xapk", ".apkm")
    private val cache = ConcurrentHashMap<String, Candidate>()
    private val observers = mutableListOf<FileObserver>()
    private val watchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            "Download", "Download/Telegram", "Documents", "Telegram/Telegram Documents",
            "Android/media/org.telegram.messenger/Telegram/Telegram Documents",
            "Android/media/org.telegram.messenger.web/Telegram/Telegram Documents",
            "Android/media/org.thunderdog.challegram/Telegram/Telegram Documents",
        ).map { File(root, it) }.filter { it.isDirectory }
    }

    /**
     * Papkalarni kuzatadi: yangi APK tushishi bilanoq tahlil qilib keshga soladi. Shunda o‘rnatish oynasi
     * ochilganda natija tayyor bo‘ladi va foydalanuvchi «O‘rnatish» ni bosib ulgurmaydi.
     */
    @Synchronized
    fun startWatching(ctx: Context) {
        stopWatching()
        if (!InstallGuard.hasFileAccess(ctx)) return
        val app = ctx.applicationContext
        for (d in dirs()) {
            @Suppress("DEPRECATION")
            val obs = object : FileObserver(d.absolutePath, FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO) {
                override fun onEvent(event: Int, path: String?) {
                    val name = path?.lowercase() ?: return
                    if (APK_EXT.none { name.endsWith(it) }) return
                    watchScope.launch {
                        delay(800)
                        runCatching { analyzeRecent(app) }
                    }
                }
            }
            obs.startWatching()
            observers += obs
        }
    }

    @Synchronized
    fun stopWatching() {
        observers.forEach { runCatching { it.stopWatching() } }
        observers.clear()
    }

    /** Oxirgi 30 daqiqada yuklangan .apk fayllarni topib tahlil qiladi (natija keshlanadi). */
    fun analyzeRecent(ctx: Context): List<Candidate> {
        val now = System.currentTimeMillis()
        val files = dirs().flatMap { d ->
            d.listFiles { f -> f.isFile && APK_EXT.any { e -> f.name.lowercase().endsWith(e) } && f.length() > 0 && now - f.lastModified() < RECENT_MS }
                ?.toList().orEmpty()
        }.sortedByDescending { it.lastModified() }.take(5)
        return files.mapNotNull { f ->
            val key = "${f.absolutePath}|${f.lastModified()}|${f.length()}"
            cache[key] ?: runCatching {
                val r = ApkAnalyzer.analyzeAny(ctx, f, null)
                Candidate(f, r.label.orEmpty(), r.packageName.orEmpty(), r, f.lastModified(),
                    f.absolutePath.contains("telegram", ignoreCase = true))
            }.getOrNull()?.also {
                if (cache.size > 50) cache.clear()
                cache[key] = it
            }
        }
    }
}

/**
 * O‘rnatishdan himoya. Faqat tizim o‘rnatuvchi oynalarini kuzatadi (xml sozlamadagi packageNames).
 * Oyna ochilganda yaqinda yuklangan APK'lar tahlil qilinadi; oynadagi ilova nomi mos kelsa va
 * tanlangan rejimga ko‘ra xavfli bo‘lsa — «Bekor qilish» tugmasi bosiladi.
 */
class InstallGuardService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var busy = false
    private var lastBlockAt = 0L
    private var lastEventAt = 0L

    // ---- Ekran vaqti cheklovi (oq ekran)
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val overlay by lazy { BlankOverlay(this) }
    private var blankActive = false
    private var lastRestrictedAt = 0L
    private var prefListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    /** Xizmat faqat o‘rnatuvchilar, do‘konlar va ota-ona cheklagan ilovalar hodisalarini oladi (boshqalarini ko‘rmaydi). */
    private fun applyPackageFilter() {
        val info = serviceInfo ?: return
        info.packageNames = (INSTALLERS + STORES + Prefs(this).restrictedApps).toTypedArray()
        serviceInfo = info
    }

    private fun handleRestricted() {
        val now = System.currentTimeMillis()
        if (blankActive || now - lastRestrictedAt < 1200) return
        if (!overlay.show()) {
            performGlobalAction(GLOBAL_ACTION_HOME) // oq ekran qo‘yib bo‘lmasa ham, ilova ochiq qolmaydi
            lastRestrictedAt = now
            return
        }
        blankActive = true
        // Oq ekran bir necha soniya turadi, so‘ng bosh ekranga qaytadi: telefon hech qachon «qotib» qolmaydi
        handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, ScreenTime.BLANK_MS)
        handler.postDelayed({
            overlay.hide()
            blankActive = false
            lastRestrictedAt = System.currentTimeMillis()
        }, ScreenTime.BLANK_MS + 500L)
    }

    private fun report(where: String, t: Throwable) {
        runCatching {
            val top = t.stackTrace.firstOrNull { it.className.startsWith("uz.safeapk") }
            Prefs(this).saveError("$where: ${t.javaClass.simpleName}: ${t.message} @ ${top?.fileName}:${top?.lineNumber}")
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching { Notifier.ensureChannels(this) }.onFailure { report("channels", it) }
        runCatching { RecentApks.startWatching(applicationContext) }.onFailure { report("watch", it) }
        runCatching { applyPackageFilter() }.onFailure { report("filter", it) }
        runCatching {
            val l = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                if (key == "restricted_apps") runCatching { applyPackageFilter() }.onFailure { report("filter2", it) }
            }
            prefListener = l
            Prefs(this).listen(l)
        }.onFailure { report("listen", it) }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching {
            prefListener?.let { Prefs(this).unlisten(it) }
            handler.removeCallbacksAndMessages(null)
            overlay.hide()
            RecentApks.stopWatching()
            scope.cancel()
        }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            handleEvent(event)
        } catch (t: Throwable) {
            report("event", t) // xato jarayonni qulatmaydi
        }
    }

    private fun handleEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        // Ota-ona cheklagan ilova ochildi: oq ekran
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg in Prefs(this).restrictedApps) {
            handleRestricted()
            return
        }
        val isInstaller = pkg in INSTALLERS
        val isStore = pkg in STORES
        if ((!isInstaller && !isStore) || busy) return
        val now = System.currentTimeMillis()
        // Kontent o‘zgarish hodisalari juda tez-tez keladi: har 250 ms dan ko‘p tekshirmaymiz
        val urgent = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED
        if (!urgent && now - lastEventAt < 250) return
        lastEventAt = now
        val prefs0 = Prefs(this)
        val mode = prefs0.blockMode
        val names = prefs0.blockedNames + Groups.enabledNames(this)
        val groupsOn = prefs0.enabledGroups.isNotEmpty()
        val lockOn = prefs0.lockUninstall && Lock.hasPin(prefs0)
        if (now - lastBlockAt < 4000) return
        if (isStore) {
            if (names.isNotEmpty()) handleStore(names)
            return
        }
        if (mode == 0 && names.isEmpty() && !groupsOn && !lockOn) return
        val root = rootInActiveWindow ?: return
        val texts = collectTexts(root)
        if (texts.isEmpty()) return
        // O‘chirish (uninstall) oynasi: faqat taqiqlangan ilova bo‘lsa, o‘chirishni o‘zi tasdiqlaydi
        if (texts.any { t -> UNINSTALL_WORDS.any { it in t } }) {
            // Safe Apk Guard ni o‘chirishga urinish: PIN / barmoq izi so‘raladi
            if (lockOn && !Lock.uninstallAllowed(prefs0) && texts.any { selfName in it }) {
                guardUninstall(root)
                return
            }
            val removeNames = names + prefs0.pendingRemove
            if (removeNames.isNotEmpty() && BlockList.find(removeNames, texts, loose = true) != null) {
                val ok = findConfirm(root)
                if (ok != null && click(ok)) {
                    lastBlockAt = now
                    prefs0.pendingRemove = emptySet()
                }
            }
            return
        }
        // Faqat «o‘rnatish» so‘rovi oynasi
        if (texts.none { t -> INSTALL_WORDS.any { it in t } }) return
        // 1) Foydalanuvchining o‘z taqiqlar ro‘yxati: rejimdan qat’i nazar ishlaydi
        if (names.isNotEmpty()) {
            val hit = BlockList.find(names, texts, loose = true)
            if (hit != null) {
                val cancel = findCancel(root)
                if (cancel != null && click(cancel)) {
                    onListBlocked(hit)
                    return
                }
            }
        }
        if (mode == 0 && !groupsOn) return
        busy = true
        scope.launch {
            try {
                evaluate(mode, texts)
            } catch (e: Exception) {
                // xizmat yiqilib qolmasligi uchun
            } finally {
                busy = false
            }
        }
    }

    /** Play Market va boshqa do‘konlar: taqiqlangan nom va «O‘rnatish» tugmasi ko‘rinsa, do‘kondan chiqarib yuboradi. */
    private fun handleStore(names: Set<String>) {
        val root = rootInActiveWindow ?: run { dbg("root=null"); return }
        val pk = root.packageName?.toString()
        if (pk !in STORES) { dbg("oyna=$pk"); return }
        val texts = collectTexts(root)
        val hit = BlockList.find(names, texts, loose = false)
        val hasInstall = texts.any { t -> t in STORE_INSTALL_BUTTONS || (t.length <= 24 && STORE_INSTALL_BUTTONS.any { t.startsWith("$it ") }) }
        val cancel = if (hit != null) findCancel(root) else null
        dbg("do‘kon=$pk matn=${texts.size} nom=${hit ?: "-"} o‘rnatish=$hasInstall bekor=${cancel != null}")
        if (hit == null || (!hasInstall && cancel == null)) return
        // Yuklash boshlangan bo‘lsa «Bekor qilish» bosiladi, so‘ng do‘kondan chiqariladi
        if (cancel != null) click(cancel)
        performGlobalAction(GLOBAL_ACTION_HOME)
        onListBlocked(hit)
    }

    private var lastDbgAt = 0L

    /** Oxirgi do‘kon tekshiruvi natijasini Sozlamalardagi «Diagnostika» qatori uchun saqlaydi. */
    private fun dbg(s: String) {
        val n = System.currentTimeMillis()
        if (n - lastDbgAt < 1500) return
        lastDbgAt = n
        Prefs(this).storeDebug = s.take(160)
    }

    private fun findConfirm(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || found != null || depth > 25 || count > 400) return
            count++
            val txt = normText(n.text?.toString()?.trim().orEmpty())
            if (txt in CONFIRM_WORDS) { found = n; return }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return found
    }

    private val selfName by lazy { normText(getString(R.string.app_name)) }

    private fun guardUninstall(root: AccessibilityNodeInfo) {
        lastBlockAt = System.currentTimeMillis()
        val cancel = findCancel(root)
        if (cancel == null || !click(cancel)) performGlobalAction(GLOBAL_ACTION_BACK)
        runCatching { startActivity(Intent(this, AuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun dbgNow(s: String) {
        lastDbgAt = System.currentTimeMillis()
        Prefs(this).storeDebug = s.take(200)
    }

    private fun onListBlocked(name: String) {
        val group = Groups.groupOfName(this, name)
        lastBlockAt = System.currentTimeMillis()
        val prefs = Prefs(this)
        prefs.blockedCount = prefs.blockedCount + 1
        runCatching {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("label", name)
                    .putExtra("listBlock", true)
                    .putExtra("group", group?.let { getString(it.title) }.orEmpty())
            )
        }
    }

    private suspend fun evaluate(mode: Int, texts: List<String>) {
        val prefsE = Prefs(this)
        val cands = withContext(Dispatchers.IO) { RecentApks.analyzeRecent(applicationContext) }
        val now = System.currentTimeMillis()
        val target = cands.firstOrNull { it.matches(texts) }
            ?: if (mode == 3) cands.firstOrNull { it.fromTelegram && now - it.modified < 5 * 60_000L } else null
        if (target != null && target.pkg.isNotEmpty() && target.pkg in prefsE.trusted) { // ishonchli deb belgilangan
            dbgNow("o‘rnatuvchi: ishonchli ilova (${target.label})")
            return
        }
        val groupHit = if (target != null) {
            withContext(Dispatchers.IO) { Groups.matchArchive(applicationContext, target.file, target.pkg, target.label) }
        } else null
        // 3-rejim: fayl topilmasa ham, o‘rnatuvchidan oldin Telegram ochiq bo‘lganmi (Foydalanish statistikasi ruxsati bilan)
        val lastApp = if (mode == 3 && target?.fromTelegram != true) {
            withContext(Dispatchers.IO) { UsageSource.lastApp(applicationContext) }
        } else null
        val tgSource = lastApp != null && UsageSource.isTelegram(lastApp)
        val level = target?.result?.level
        val modeBlock = when (mode) {
            1 -> level == Level.BAD
            2 -> level != null && level != Level.OK
            3 -> target?.fromTelegram == true || tgSource || (level != null && level != Level.OK)
            4 -> true // qat’iy: fayl topilmasa ham barcha APK o‘rnatish oynalari
            else -> false
        }
        val block = groupHit != null || modeBlock
        val root = rootInActiveWindow
        val cancel = if (block && root != null && root.packageName?.toString() in INSTALLERS) findCancel(root) else null
        dbgNow(
            "o‘rnatuvchi rejim=$mode fayl=${cands.size} mos=${target?.label ?: "-"} manba=${lastApp ?: "-"} " +
                "guruh=${groupHit?.id ?: "-"} blok=$block bekor=${cancel != null}"
        )
        if (!block || cancel == null) return
        if (!click(cancel)) return

        lastBlockAt = System.currentTimeMillis()
        val prefs = Prefs(this)
        prefs.blockedCount = prefs.blockedCount + 1
        val lctx = Lang.wrap(this)
        val label = target?.label?.ifBlank { null } ?: target?.file?.name ?: lctx.getString(R.string.blocked_unknown)
        Notifier.blocked(lctx, label)
        runCatching {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("label", label)
                    .putExtra("pkg", target?.pkg.orEmpty())
                    .putExtra("reasons", target?.result?.flags?.take(4)?.map { lctx.getString(it.reason) }?.toTypedArray() ?: emptyArray<String>())
                    .putExtra("group", groupHit?.let { lctx.getString(it.title) }.orEmpty())
            )
        }
    }

    private fun collectTexts(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 25 || count > 400) return
            count++
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out += normText(it) }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out += normText(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    private fun findCancel(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || found != null || depth > 25 || count > 400) return
            count++
            val id = n.viewIdResourceName?.lowercase().orEmpty()
            val txt = normText(n.text?.toString()?.trim().orEmpty())
            if (id.contains("cancel") || txt in CANCEL_WORDS) {
                found = n
                return
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return found
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 5) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    companion object {
        private val INSTALLERS = setOf(
            "com.google.android.packageinstaller", "com.android.packageinstaller",
            "com.samsung.android.packageinstaller", "com.miui.packageinstaller",
            "com.oplus.appdetail", // Oppo / Realme / OnePlus (ColorOS, OxygenOS)
        )
        /** Ilova do‘konlari (ba’zi nomlar qurilmada bo‘lmasligi mumkin — zarari yo‘q). */
        private val STORES = setOf(
            "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket", "com.xiaomi.mipicks",
            "com.heytap.market", "com.vivo.appstore", "org.fdroid.fdroid", "cm.aptoide.pt", "com.apkpure.aegon",
        )
        private val STORE_INSTALL_BUTTONS = setOf(
            "install", "get", "download", "o'rnatish", "yuklab olish", "yuklash", "установить", "скачать", "ўрнатиш",
        )
        private val INSTALL_WORDS = listOf("install", "o'rnat", "ўрнат", "установ")
        private val UNINSTALL_WORDS = listOf("uninstall", "o'chir", "ўчир", "удал", "delete")
        private val CONFIRM_WORDS = setOf("ok", "uninstall", "delete", "o'chirish", "ўчириш", "удалить", "ок")
        private val CANCEL_WORDS = setOf("cancel", "bekor qilish", "bekor", "bekor qil", "отмена")
    }
}
