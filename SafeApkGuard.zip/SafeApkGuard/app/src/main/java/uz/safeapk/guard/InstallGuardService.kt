package uz.safeapk.guard

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.safeapk.guard.analysis.ApkAnalyzer
import uz.safeapk.guard.analysis.Level
import uz.safeapk.guard.analysis.ScanResult

/** Holat va ruxsatlarni tekshiruvchi yordamchilar (Sozlamalar ekrani uchun). */
object InstallGuard {
    fun isAccessibilityOn(ctx: Context): Boolean {
        val enabled = Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
        if (!enabled) return false
        val me = ComponentName(ctx, InstallGuardService::class.java)
        return Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            .orEmpty().split(':').mapNotNull { ComponentName.unflattenFromString(it) }.any { it == me }
    }

    fun hasFileAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

/** Yaqinda yuklangan APK fayl va uning tahlili. */
class Candidate(
    val file: File, val label: String, val pkg: String, val result: ScanResult,
    val modified: Long, val fromTelegram: Boolean,
) {
    /** O‘rnatish oynasidagi matnlarda shu ilova nomi yoki paketi bormi. */
    fun matches(texts: List<String>): Boolean {
        val l = label.lowercase()
        val p = pkg.lowercase()
        return (l.length >= 3 && texts.any { it.contains(l) }) || (p.isNotEmpty() && texts.any { it.contains(p) })
    }
}

object RecentApks {
    private const val RECENT_MS = 30 * 60_000L
    private val APK_EXT = listOf(".apk", ".apks", ".xapk", ".apkm")
    private val cache = ConcurrentHashMap<String, Candidate>()

    private fun dirs(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return listOf(
            "Download", "Download/Telegram", "Documents", "Telegram/Telegram Documents",
            "Android/media/org.telegram.messenger/Telegram/Telegram Documents",
            "Android/media/org.telegram.messenger.web/Telegram/Telegram Documents",
            "Android/media/org.thunderdog.challegram/Telegram/Telegram Documents",
        ).map { File(root, it) }.filter { it.isDirectory }
    }

    /** Oxirgi 30 daqiqada yuklangan .apk fayllarni topib tahlil qiladi (natija keshlanadi). */
    fun analyzeRecent(ctx: Context): List<Candidate> {
        val now = System.currentTimeMillis()
        val files = dirs().flatMap { d ->
            d.listFiles { f -> f.isFile && APK_EXT.any { e -> f.name.lowercase().endsWith(e) } && f.length() > 0 && now - f.lastModified() < RECENT_MS }
                ?.toList().orEmpty()
        }.sortedByDescending { it.lastModified() }.take(5)
        return files.mapNotNull { f ->
            val key = "${f.absolutePath}|${f.lastModified()}|${f.length()}"
            cache[key] ?: runCatching {
                val r = ApkAnalyzer.analyzeAny(ctx, f, null)
                Candidate(f, r.label.orEmpty(), r.packageName.orEmpty(), r, f.lastModified(),
                    f.absolutePath.contains("telegram", ignoreCase = true))
            }.getOrNull()?.also {
                if (cache.size > 50) cache.clear()
                cache[key] = it
            }
        }
    }
}

/**
 * O‘rnatishdan himoya. Faqat tizim o‘rnatuvchi oynalarini kuzatadi (xml sozlamadagi packageNames).
 * Oyna ochilganda yaqinda yuklangan APK'lar tahlil qilinadi; oynadagi ilova nomi mos kelsa va
 * tanlangan rejimga ko‘ra xavfli bo‘lsa — «Bekor qilish» tugmasi bosiladi.
 */
class InstallGuardService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var busy = false
    private var lastBlockAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Notifier.ensureChannels(this)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in INSTALLERS || busy) return
        val mode = Prefs(this).blockMode
        if (mode == 0 || System.currentTimeMillis() - lastBlockAt < 4000) return
        val root = rootInActiveWindow ?: return
        val texts = collectTexts(root)
        if (texts.isEmpty()) return
        // O‘chirish (uninstall) oynasiga tegmaymiz
        if (texts.any { t -> UNINSTALL_WORDS.any { it in t } }) return
        // Faqat «o‘rnatish» so‘rovi oynasi
        if (texts.none { t -> INSTALL_WORDS.any { it in t } }) return
        busy = true
        scope.launch {
            try {
                evaluate(mode, texts)
            } catch (e: Exception) {
                // xizmat yiqilib qolmasligi uchun
            } finally {
                busy = false
            }
        }
    }

    private suspend fun evaluate(mode: Int, texts: List<String>) {
        val cands = withContext(Dispatchers.IO) { RecentApks.analyzeRecent(applicationContext) }
        if (cands.isEmpty()) return
        val now = System.currentTimeMillis()
        val target = cands.firstOrNull { it.matches(texts) }
            ?: if (mode == 3) cands.firstOrNull { it.fromTelegram && now - it.modified < 5 * 60_000L } else null
        if (target == null) return
        val block = when (mode) {
            1 -> target.result.level == Level.BAD
            2 -> target.result.level != Level.OK
            else -> target.fromTelegram || target.result.level != Level.OK
        }
        if (!block) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in INSTALLERS) return
        val cancel = findCancel(root) ?: return
        if (!click(cancel)) return

        lastBlockAt = System.currentTimeMillis()
        val prefs = Prefs(this)
        prefs.blockedCount = prefs.blockedCount + 1
        val label = target.label.ifBlank { target.file.name }
        val lctx = Lang.wrap(this)
        Notifier.blocked(lctx, label)
        runCatching {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("label", label)
                    .putExtra("reasons", target.result.flags.take(4).map { lctx.getString(it.reason) }.toTypedArray())
            )
        }
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[‘’ʻʼ`´]"), "'")

    private fun collectTexts(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 25 || count > 400) return
            count++
            n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out += norm(it) }
            n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out += norm(it) }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    private fun findCancel(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || found != null || depth > 25 || count > 400) return
            count++
            val id = n.viewIdResourceName?.lowercase().orEmpty()
            val txt = norm(n.text?.toString()?.trim().orEmpty())
            if (id.contains("cancel") || txt in CANCEL_WORDS) {
                found = n
                return
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return found
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 5) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            hops++
        }
        return false
    }

    companion object {
        private val INSTALLERS = setOf(
            "com.google.android.packageinstaller", "com.android.packageinstaller",
            "com.samsung.android.packageinstaller", "com.miui.packageinstaller",
        )
        private val INSTALL_WORDS = listOf("install", "o'rnat", "ўрнат", "установ")
        private val UNINSTALL_WORDS = listOf("uninstall", "o'chir", "ўчир", "удал", "delete")
        private val CANCEL_WORDS = setOf("cancel", "bekor qilish", "bekor", "bekor qil", "отмена")
    }
}
