package uz.safeapk.guard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import uz.safeapk.guard.analysis.Level

data class HistoryItem(val time: Long, val level: Level, val title: String, val name: String)

/** Oxirgi tekshiruvlar tarixi. Faqat telefonda (SharedPreferences) saqlanadi. */
object History {
    private const val MAX = 30

    @Synchronized
    fun add(ctx: Context, v: Verdict) {
        runCatching {
            val prefs = Prefs(ctx)
            val old = JSONArray(prefs.history)
            val out = JSONArray()
            out.put(
                JSONObject()
                    .put("t", System.currentTimeMillis())
                    .put("l", v.level.ordinal)
                    .put("title", v.title)
                    .put("name", v.meta.firstOrNull()?.second.orEmpty())
            )
            for (i in 0 until minOf(old.length(), MAX - 1)) out.put(old.get(i))
            prefs.history = out.toString()
        }
    }

    @Synchronized
    fun all(ctx: Context): List<HistoryItem> = runCatching {
        val arr = JSONArray(Prefs(ctx).history)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryItem(o.getLong("t"), Level.values()[o.getInt("l")], o.getString("title"), o.optString("name"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun clear(ctx: Context) {
        Prefs(ctx).history = "[]"
    }
}
