package uz.safeapk.guard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.view.View
import android.view.WindowManager

/** Ekran vaqti cheklovi: cheklangan ilova ochilganda oq ekran («ilova ishlamayapti»), so‘ng bosh ekranga qaytish. */
object ScreenTime {
    /** Oq ekran necha millisekund ko‘rinib turadi (so‘ng telefon bosh ekranga qaytadi). */
    const val BLANK_MS = 3000L

    /** Cheklab bo‘lmaydigan paketlar: o‘zimiz, bosh ekran (launcher), telefon/dialer, sozlamalar, tizim. */
    fun protectedPackages(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = mutableSetOf(
            ctx.packageName, "com.android.settings", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.emergency", "com.google.android.dialer",
            "com.samsung.android.dialer", "com.android.dialer",
        )
        val probes = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            Intent(Intent.ACTION_DIAL),
        )
        for (i in probes) {
            runCatching { pm.queryIntentActivities(i, 0).forEach { out += it.activityInfo.packageName } }
        }
        return out
    }

    /** (nom, paket) juftliklari: ishga tushiriladigan, himoyalanmagan ilovalar. */
    fun launchableApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val skip = protectedPackages(ctx)
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0).mapNotNull { ri ->
            val p = ri.activityInfo.packageName
            if (p in skip) null else ri.loadLabel(pm).toString() to p
        }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    fun labelOf(ctx: Context, pkg: String): String = runCatching {
        val pm = ctx.packageManager
        pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
    }.getOrDefault(pkg)
}

/**
 * To‘liq ekranli oq oyna. Maxsus imkoniyatlar xizmati (TYPE_ACCESSIBILITY_OVERLAY) orqali ko‘rsatiladi,
 * qo‘shimcha «boshqa ilovalar ustida ko‘rsatish» ruxsati kerak emas.
 */
class BlankOverlay(private val svc: AccessibilityService) {
    private var view: View? = null

    val active: Boolean get() = view != null

    fun show(): Boolean {
        if (view != null) return true
        return runCatching {
            val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(svc).apply {
                setBackgroundColor(Color.WHITE)
                isClickable = true // teginishlarni pastdagi ilovaga o‘tkazmaydi
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE,
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp)
            view = v
            true
        }.getOrDefault(false)
    }

    fun hide() {
        val v = view ?: return
        view = null
        runCatching {
            val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(v)
        }
    }
}
