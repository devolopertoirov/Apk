package uz.safeapk.guard.analysis

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppResult(val packageName: String, val label: String, val result: ScanResult)

/** Hozir yoqilgan xavfli xizmatlar (haqiqiy faol holat — ruxsat so‘ralgani emas). */
class ActiveSets(val access: Set<String>, val notif: Set<String>, val admin: Set<String>)

object AppScanner {
    private val TRUSTED_STORES = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "com.huawei.appmarket", "com.xiaomi.mipicks", "com.heytap.market",
    )
    private val TELEGRAM_APPS = setOf(
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "org.telegram.plus", "com.exteragram.messenger",
    )
    private val HEAVY = setOf(Flag.SMS_READ, Flag.ACCESS, Flag.NOTIF, Flag.DEVADMIN)

    fun loadActive(ctx: Context): ActiveSets {
        val acc = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            .orEmpty().split(':').map { it.substringBefore('/') }.filter { it.isNotBlank() }.toSet()
        val notif = runCatching { NotificationManagerCompat.getEnabledListenerPackages(ctx) }.getOrDefault(emptySet())
        val admin = runCatching {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.activeAdmins?.map { it.packageName }?.toSet().orEmpty()
        }.getOrDefault(emptySet())
        return ActiveSets(acc, notif, admin)
    }

    private fun isSystem(ai: ApplicationInfo) = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0

    /** Foydalanuvchi o‘rnatgan (tizimniki emas) ilovalar paketlari. */
    fun userPackages(ctx: Context): Set<String> =
        Compat.installedApps(ctx.packageManager)
            .filter { !isSystem(it) && it.packageName != ctx.packageName }
            .map { it.packageName }.toSet()

    suspend fun scanAll(ctx: Context): List<AppResult> = withContext(Dispatchers.Default) {
        val active = loadActive(ctx)
        userPackages(ctx).mapNotNull { analyzeInstalled(ctx, it, active) }
            .sortedWith(compareByDescending<AppResult> { it.result.score }.thenBy { it.label.lowercase() })
    }

    fun analyzeInstalled(ctx: Context, pkg: String, active: ActiveSets = loadActive(ctx)): AppResult? {
        val pm = ctx.packageManager
        val pi = Compat.packageInfo(pm, pkg, ApkAnalyzer.MANIFEST_FLAGS) ?: return null
        val ai = pi.applicationInfo ?: return null
        if (isSystem(ai)) return null

        val flags = ApkAnalyzer.flagsFromPackageInfo(pi)
        if (pkg in active.access) flags += Flag.ACTIVE_ACCESS
        if (pkg in active.notif) flags += Flag.ACTIVE_NOTIF
        if (pkg in active.admin) flags += Flag.ACTIVE_ADMIN

        // Qayerdan o‘rnatilgan: rasmiy do‘kon — ishonch, Telegramdan yuklangan fayl — xavf belgisi
        var installer: String? = null
        var initiator: String? = null
        runCatching {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val src = pm.getInstallSourceInfo(pkg)
                installer = src.installingPackageName
                initiator = src.initiatingPackageName
            } else {
                @Suppress("DEPRECATION")
                installer = pm.getInstallerPackageName(pkg)
            }
        }
        var adjust = 0
        when {
            installer in TRUSTED_STORES -> adjust = -25
            initiator in TELEGRAM_APPS || installer in TELEGRAM_APPS -> flags += Flag.FROM_TELEGRAM
            else -> flags += Flag.SIDELOADED
        }

        // Og‘ir ZIP tekshiruvi faqat gumonli belgilari bor ilovalar uchun (tezlik uchun)
        if (flags.any { it in HEAVY }) {
            ai.sourceDir?.let { flags += ApkAnalyzer.scanZip(File(it)) }
        }
        val label = runCatching { ai.loadLabel(pm).toString() }.getOrDefault(pkg)
        return AppResult(pkg, label, Scoring.build(flags, adjust, pkg, label, null))
    }
}
