package uz.safeapk.guard

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/** «Ulashish» (Share) yoki «Ochish» orqali kelgan APK fayl yoki havolani tekshiradi. */
class ShareActivity : ComponentActivity() {
    private var verdict by mutableStateOf<Verdict?>(null)
    private var error by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GuardTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Text(stringResource(R.string.app_name), style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                        val v = verdict
                        val e = error
                        when {
                            v != null -> VerdictCard(v)
                            e != null -> Text(e, color = RedBad)
                            else -> Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.width(28.dp).height(28.dp), strokeWidth = 3.dp)
                                Spacer(Modifier.width(12.dp))
                                Text(stringResource(R.string.share_loading))
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Button(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.btn_close))
                        }
                    }
                }
            }
        }
        handle(intent)
    }

    private fun streamUri(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)

    private fun handle(i: Intent) {
        val uri: Uri? = when (i.action) {
            Intent.ACTION_SEND -> streamUri(i)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        val text = if (i.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT) else null
        lifecycleScope.launch {
            try {
                when {
                    uri != null -> verdict = Checker.checkUri(applicationContext, uri)
                    !text.isNullOrBlank() -> {
                        val v = Checker.checkText(applicationContext, text)
                        if (v == null) error = getString(R.string.no_input) else verdict = v
                    }
                    else -> error = getString(R.string.no_input)
                }
            } catch (e: Exception) {
                error = getString(R.string.check_error)
            }
        }
    }
}
