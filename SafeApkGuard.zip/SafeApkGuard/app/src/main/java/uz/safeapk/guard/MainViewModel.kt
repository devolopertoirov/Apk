package uz.safeapk.guard

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import uz.safeapk.guard.analysis.AppResult
import uz.safeapk.guard.analysis.AppScanner

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppResult>?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var checking by mutableStateOf(false)
        private set
    var verdict by mutableStateOf<Verdict?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var realtime by mutableStateOf(prefs.realtime)
        private set
    var periodic by mutableStateOf(prefs.periodic)
        private set
    var blockMode by mutableStateOf(prefs.blockMode)
        private set
    val blockedCount: Int get() = prefs.blockedCount
    var theme by mutableStateOf(prefs.theme)
        private set
    var lang by mutableStateOf(prefs.lang)
        private set
    var stored by mutableStateOf<List<StoredApk>?>(null)
        private set
    var storageScanning by mutableStateOf(false)
        private set
    var deletedFiles by mutableStateOf(prefs.deletedFiles)
        private set
    var storageProgress by mutableStateOf(0 to 0)
        private set
    var trusted by mutableStateOf(prefs.trusted)
        private set
    var history by mutableStateOf<List<HistoryItem>>(emptyList())
        private set
    private var storageJob: Job? = null
    var blockedNames by mutableStateOf(prefs.blockedNames.sortedBy { it.lowercase() })
        private set

    private val ctx get() = getApplication<Application>()

    fun scanApps() {
        if (scanning) return
        scanning = true
        viewModelScope.launch {
            apps = runCatching { AppScanner.scanAll(ctx) }.getOrDefault(emptyList())
            scanning = false
        }
    }

    fun checkFile(uri: Uri) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkUri(ctx, uri) }
                .onSuccess { verdict = it }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
            refreshHistory()
        }
    }

    fun checkLink(text: String) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkText(ctx, text) }
                .onSuccess { v -> if (v == null) error = ctx.getString(R.string.no_input) else verdict = v }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
            refreshHistory()
        }
    }

    fun addBlockedName(raw: String): Boolean {
        val n = BlockList.clean(raw)
        val cur = prefs.blockedNames
        if (n.length < 2 || cur.size >= BlockList.MAX_NAMES || cur.any { it.equals(n, ignoreCase = true) }) return false
        prefs.blockedNames = cur + n
        blockedNames = prefs.blockedNames.sortedBy { it.lowercase() }
        return true
    }

    fun removeBlockedName(n: String) {
        prefs.blockedNames = prefs.blockedNames - n
        blockedNames = prefs.blockedNames.sortedBy { it.lowercase() }
    }

    fun refreshHistory() { history = History.all(ctx) }

    fun clearHistory() {
        History.clear(ctx)
        history = emptyList()
    }

    fun trust(pkg: String) {
        prefs.trusted = prefs.trusted + pkg
        trusted = prefs.trusted
        scanApps()
    }

    fun untrust(pkg: String) {
        prefs.trusted = prefs.trusted - pkg
        trusted = prefs.trusted
        scanApps()
    }

    fun updateRealtime(on: Boolean) {
        prefs.realtime = on
        realtime = on
        if (on) GuardService.start(ctx) else GuardService.stop(ctx)
    }

    fun updatePeriodic(on: Boolean) {
        prefs.periodic = on
        periodic = on
        NewAppChecker.schedule(ctx, on)
    }

    fun updateBlockMode(m: Int) {
        prefs.blockMode = m
        blockMode = m
    }

    fun updateTheme(t: Int) {
        prefs.theme = t
        theme = t
    }

    fun updateLang(code: String) {
        prefs.lang = code
        lang = code
    }

    fun scanStorage() {
        if (storageScanning) return
        storageScanning = true
        storageProgress = 0 to 0
        storageJob = viewModelScope.launch {
            val r = try {
                StorageScan.scan(ctx) { d, t -> storageProgress = d to t }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            stored = r
            storageScanning = false
        }
    }

    fun cancelStorageScan() {
        storageJob?.cancel()
        storageScanning = false
    }

    fun deleteStored(file: java.io.File) {
        if (runCatching { file.delete() }.getOrDefault(false)) {
            prefs.deletedFiles = prefs.deletedFiles + 1
            deletedFiles = prefs.deletedFiles
            stored = stored?.filter { it.file != file }
        }
    }
}
