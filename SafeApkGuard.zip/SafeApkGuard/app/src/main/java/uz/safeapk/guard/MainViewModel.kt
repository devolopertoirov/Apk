package uz.safeapk.guard

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import uz.safeapk.guard.analysis.AppResult
import uz.safeapk.guard.analysis.AppScanner

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppResult>?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var checking by mutableStateOf(false)
        private set
    var verdict by mutableStateOf<Verdict?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var realtime by mutableStateOf(prefs.realtime)
        private set
    var periodic by mutableStateOf(prefs.periodic)
        private set
    var blockMode by mutableStateOf(prefs.blockMode)
        private set
    val blockedCount: Int get() = prefs.blockedCount
    var theme by mutableStateOf(prefs.theme)
        private set
    var lang by mutableStateOf(prefs.lang)
        private set
    var stored by mutableStateOf<List<StoredApk>?>(null)
        private set
    var storageScanning by mutableStateOf(false)
        private set
    var deletedFiles by mutableStateOf(prefs.deletedFiles)
        private set

    private val ctx get() = getApplication<Application>()

    fun scanApps() {
        if (scanning) return
        scanning = true
        viewModelScope.launch {
            apps = runCatching { AppScanner.scanAll(ctx) }.getOrDefault(emptyList())
            scanning = false
        }
    }

    fun checkFile(uri: Uri) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkUri(ctx, uri) }
                .onSuccess { verdict = it }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
        }
    }

    fun checkLink(text: String) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkText(ctx, text) }
                .onSuccess { v -> if (v == null) error = ctx.getString(R.string.no_input) else verdict = v }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
        }
    }

    fun updateRealtime(on: Boolean) {
        prefs.realtime = on
        realtime = on
        if (on) GuardService.start(ctx) else GuardService.stop(ctx)
    }

    fun updatePeriodic(on: Boolean) {
        prefs.periodic = on
        periodic = on
        NewAppChecker.schedule(ctx, on)
    }

    fun updateBlockMode(m: Int) {
        prefs.blockMode = m
        blockMode = m
    }

    fun updateTheme(t: Int) {
        prefs.theme = t
        theme = t
    }

    fun updateLang(code: String) {
        prefs.lang = code
        lang = code
    }

    fun scanStorage() {
        if (storageScanning) return
        storageScanning = true
        viewModelScope.launch {
            stored = runCatching { StorageScan.scan(ctx) }.getOrDefault(emptyList())
            storageScanning = false
        }
    }

    fun deleteStored(file: java.io.File) {
        if (runCatching { file.delete() }.getOrDefault(false)) {
            prefs.deletedFiles = prefs.deletedFiles + 1
            deletedFiles = prefs.deletedFiles
            stored = stored?.filter { it.file != file }
        }
    }
}
