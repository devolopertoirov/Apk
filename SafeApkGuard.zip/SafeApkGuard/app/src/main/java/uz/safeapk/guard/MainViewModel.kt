package uz.safeapk.guard

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import uz.safeapk.guard.analysis.AppResult
import uz.safeapk.guard.analysis.AppScanner

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppResult>?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var checking by mutableStateOf(false)
        private set
    var verdict by mutableStateOf<Verdict?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var realtime by mutableStateOf(prefs.realtime)
        private set
    var periodic by mutableStateOf(prefs.periodic)
        private set

    private val ctx get() = getApplication<Application>()

    fun scanApps() {
        if (scanning) return
        scanning = true
        viewModelScope.launch {
            apps = runCatching { AppScanner.scanAll(ctx) }.getOrDefault(emptyList())
            scanning = false
        }
    }

    fun checkFile(uri: Uri) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkUri(ctx, uri) }
                .onSuccess { verdict = it }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
        }
    }

    fun checkLink(text: String) {
        checking = true; verdict = null; error = null
        viewModelScope.launch {
            runCatching { Checker.checkText(ctx, text) }
                .onSuccess { v -> if (v == null) error = ctx.getString(R.string.no_input) else verdict = v }
                .onFailure { error = ctx.getString(R.string.check_error) }
            checking = false
        }
    }

    fun updateRealtime(on: Boolean) {
        prefs.realtime = on
        realtime = on
        if (on) GuardService.start(ctx) else GuardService.stop(ctx)
    }

    fun updatePeriodic(on: Boolean) {
        prefs.periodic = on
        periodic = on
        NewAppChecker.schedule(ctx, on)
    }
}
