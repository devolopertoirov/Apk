package uz.safeapk.guard

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

fun biometricAvailable(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun showBiometric(act: FragmentActivity, title: String, cancel: String, onOk: () -> Unit) {
    val prompt = BiometricPrompt(
        act, ContextCompat.getMainExecutor(act),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onOk()
            }
        },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setNegativeButtonText(cancel)
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    prompt.authenticate(info)
}

/** Butun ekran PIN oynasi (ilovani ochish va o‘chirishga ruxsat uchun). */
@Composable
fun PinGate(title: String, allowBiometric: Boolean, onSuccess: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val bioTitle = stringResource(R.string.lock_bio_prompt)
    val bioCancel = stringResource(R.string.btn_cancel)
    val wrongText = stringResource(R.string.pin_wrong)
    val lockedFmt = stringResource(R.string.pin_locked)
    val confirmText = stringResource(R.string.pin_confirm)
    val act = ctx as? FragmentActivity
    val canBio = allowBiometric && prefs.useBiometric && act != null && biometricAvailable(ctx)

    fun launchBio() {
        if (canBio && act != null) showBiometric(act, bioTitle, bioCancel, onSuccess)
    }

    LaunchedEffect(Unit) { launchBio() }

    fun submit() {
        when (val r = Lock.verify(prefs, pin)) {
            is PinResult.Ok -> onSuccess()
            is PinResult.Wrong -> { error = wrongText; pin = "" }
            is PinResult.Locked -> { error = lockedFmt.format(r.seconds); pin = "" }
        }
    }

    @Composable
    fun Key(label: String, onClick: () -> Unit) {
        OutlinedButton(onClick = onClick, modifier = Modifier.size(width = 76.dp, height = 56.dp), contentPadding = PaddingValues(0.dp)) {
            Text(label, style = MaterialTheme.typography.titleLarge)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text((0 until 8).joinToString(" ") { if (it < pin.length) "●" else "○" }, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(error ?: " ", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { d -> Key(d) { if (pin.length < 8) pin += d; error = null } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (canBio) Key("👆") { launchBio() } else Spacer(Modifier.size(width = 76.dp, height = 56.dp))
                Key("0") { if (pin.length < 8) pin += "0"; error = null }
                Key("⌫") { pin = pin.dropLast(1) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { submit() }, enabled = pin.length >= 4, modifier = Modifier.fillMaxWidth()) { Text(confirmText) }
    }
}

@Composable
fun SetPinDialog(onDismiss: () -> Unit, onDone: (String) -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.pin_dialog_set)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = p1, onValueChange = { p1 = it.filter(Char::isDigit).take(8) }, singleLine = true,
                    label = { Text(stringResource(R.string.pin_hint_new)) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                OutlinedTextField(
                    value = p2, onValueChange = { p2 = it.filter(Char::isDigit).take(8) }, singleLine = true,
                    label = { Text(stringResource(R.string.pin_hint_repeat)) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                if (err) Text(stringResource(R.string.pin_mismatch), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (p1.length in 4..8 && p1 == p2) onDone(p1) else err = true }) {
                Text(stringResource(R.string.pin_confirm))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.btn_cancel)) } },
    )
}

@Composable
fun VerifyPinDialog(onDismiss: () -> Unit, onOk: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val wrongText = stringResource(R.string.pin_wrong)
    val lockedFmt = stringResource(R.string.pin_locked)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.pin_gate_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8); err = null }, singleLine = true,
                    label = { Text(stringResource(R.string.pin_hint_current)) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (val r = Lock.verify(prefs, pin)) {
                    is PinResult.Ok -> onOk()
                    is PinResult.Wrong -> { err = wrongText; pin = "" }
                    is PinResult.Locked -> { err = lockedFmt.format(r.seconds); pin = "" }
                }
            }) { Text(stringResource(R.string.pin_confirm)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.btn_cancel)) } },
    )
}

/**
 * Himoyani kuchsizlantiradigan amallar (guruhni o‘chirish, ro‘yxatdan nom olish, PINni o‘chirish...) uchun:
 * PIN o‘rnatilgan bo‘lsa avval PIN so‘raydi, bo‘lmasa darrov bajaradi.
 */
@Composable
fun rememberPinGuard(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    pending?.let { act ->
        VerifyPinDialog(onDismiss = { pending = null }, onOk = { pending = null; act() })
    }
    return { action -> if (Lock.hasPin(Prefs(ctx))) pending = action else action() }
}

@Composable
fun LockSection() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var tick by remember { mutableStateOf(0) }
    val hasPin = remember(tick) { Lock.hasPin(prefs) }
    val lockOpen = remember(tick) { prefs.lockOpen }
    val lockUn = remember(tick) { prefs.lockUninstall }
    val useBio = remember(tick) { prefs.useBiometric }
    val bioOk = remember { biometricAvailable(ctx) }
    var showSet by remember { mutableStateOf(false) }
    var changeAfterVerify by remember { mutableStateOf(false) }
    val guard = rememberPinGuard()

    if (showSet) {
        SetPinDialog(onDismiss = { showSet = false }, onDone = { pin ->
            Lock.setPin(prefs, pin)
            Lock.touch()
            showSet = false
            tick++
        })
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.lock_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.lock_desc), style = MaterialTheme.typography.bodySmall)
            if (!hasPin) {
                Button(onClick = { showSet = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.pin_set)) }
            } else {
                SwitchRow(stringResource(R.string.lock_open_title), stringResource(R.string.lock_open_desc), lockOpen) { on ->
                    if (on) { prefs.lockOpen = true; tick++ } else guard { prefs.lockOpen = false; tick++ }
                }
                if (bioOk) {
                    SwitchRow(stringResource(R.string.lock_bio_title), stringResource(R.string.lock_bio_desc), useBio) { on ->
                        if (on) { prefs.useBiometric = true; tick++ } else guard { prefs.useBiometric = false; tick++ }
                    }
                }
                SwitchRow(stringResource(R.string.lock_uninstall_title), stringResource(R.string.lock_uninstall_desc), lockUn) { on ->
                    if (on) { prefs.lockUninstall = true; tick++ } else guard { prefs.lockUninstall = false; tick++ }
                }
                if (lockUn && !InstallGuard.isAccessibilityOn(ctx)) {
                    Text(stringResource(R.string.lock_uninstall_need_access), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { guard { showSet = true } }) { Text(stringResource(R.string.pin_change)) }
                    OutlinedButton(onClick = { guard { Lock.clearPin(prefs); tick++ } }) { Text(stringResource(R.string.pin_remove)) }
                }
            }
            Text(stringResource(R.string.pin_forgot), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun GroupsSection() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var on by remember { mutableStateOf(prefs.enabledGroups) }
    val guard = rememberPinGuard()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.groups_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.groups_desc), style = MaterialTheme.typography.bodySmall)
            Groups.ALL.forEach { g ->
                SwitchRow(stringResource(g.title), stringResource(g.desc), g.id in on) { enable ->
                    if (enable) {
                        prefs.enabledGroups = prefs.enabledGroups + g.id
                        on = prefs.enabledGroups
                    } else {
                        guard {
                            prefs.enabledGroups = prefs.enabledGroups - g.id
                            on = prefs.enabledGroups
                        }
                    }
                }
            }
            if (on.isNotEmpty() && !InstallGuard.isAccessibilityOn(ctx)) {
                Text(stringResource(R.string.groups_need_access), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            Text(stringResource(R.string.groups_note), style = MaterialTheme.typography.labelSmall)
        }
    }
}
