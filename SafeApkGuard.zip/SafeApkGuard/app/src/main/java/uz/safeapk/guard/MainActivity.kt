package uz.safeapk.guard

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import uz.safeapk.guard.analysis.AppResult
import uz.safeapk.guard.analysis.Level

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GuardTheme {
                val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                androidx.compose.runtime.LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    if (vm.apps == null) vm.scanApps()
                }
                MainScreen(vm)
            }
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text(stringResource(R.string.tab_apps)) })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text(stringResource(R.string.tab_check)) })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Settings, null) }, label = { Text(stringResource(R.string.tab_settings)) })
            }
        },
    ) { pad ->
        Surface(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> AppsTab(vm)
                1 -> CheckTab(vm)
                else -> SettingsTab(vm)
            }
        }
    }
}

@Composable
fun AppsTab(vm: MainViewModel) {
    val apps = vm.apps
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.apps_intro), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.scanApps() }, enabled = !vm.scanning, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (vm.scanning) R.string.apps_scanning else R.string.apps_scan))
        }
        Spacer(Modifier.height(12.dp))
        if (vm.scanning && apps == null) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        } else if (apps != null) {
            val risky = apps.count { it.result.level != Level.OK }
            Text(stringResource(R.string.apps_summary, apps.size, risky), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(apps, key = { it.packageName }) { AppRow(it) }
            }
        }
    }
}

@Composable
fun AppRow(item: AppResult) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val r = item.result
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LevelIcon(r.level, 24)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.label, fontWeight = FontWeight.SemiBold)
                    Text(item.packageName, style = MaterialTheme.typography.bodySmall)
                }
                Text(levelLabel(r.level), color = levelColor(r.level), fontWeight = FontWeight.Bold)
            }
            if (open) {
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.score_fmt, r.score), style = MaterialTheme.typography.bodySmall)
                r.flags.take(6).forEach { Text("• " + stringResource(it.reason), style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text(stringResource(R.string.btn_app_settings)) }
                    Button(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text(stringResource(R.string.btn_uninstall)) }
                }
            }
        }
    }
}

@Composable
fun CheckTab(vm: MainViewModel) {
    var link by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.checkFile(uri)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.check_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.check_hint), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.checking, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.btn_pick_file))
        }
        OutlinedTextField(
            value = link, onValueChange = { link = it }, label = { Text(stringResource(R.string.link_label)) },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(
            onClick = { vm.checkLink(link) }, enabled = !vm.checking && link.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(stringResource(R.string.btn_check_link)) }
        if (vm.checking) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.width(24.dp).height(24.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.checking))
            }
        }
        vm.error?.let { Text(it, color = RedBad) }
        vm.verdict?.let { VerdictCard(it) }
    }
}

@Composable
fun SettingsTab(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(stringResource(R.string.tab_settings), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SwitchRow(stringResource(R.string.settings_realtime), stringResource(R.string.settings_realtime_desc), vm.realtime) { vm.updateRealtime(it) }
        SwitchRow(stringResource(R.string.settings_periodic), stringResource(R.string.settings_periodic_desc), vm.periodic) { vm.updatePeriodic(it) }
        Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
