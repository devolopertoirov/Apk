package uz.safeapk.guard

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import uz.safeapk.guard.analysis.AppResult
import uz.safeapk.guard.analysis.Level

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GuardTheme(vm.theme) {
                val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    if (vm.apps == null) vm.scanApps()
                }
                MainScreen(vm)
            }
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text(stringResource(R.string.tab_apps), maxLines = 1) })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text(stringResource(R.string.tab_check), maxLines = 1) })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.AutoMirrored.Filled.List, null) }, label = { Text(stringResource(R.string.tab_storage), maxLines = 1) })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Filled.Settings, null) }, label = { Text(stringResource(R.string.tab_settings), maxLines = 1) })
                NavigationBarItem(tab == 4, { tab = 4 }, { Icon(Icons.Filled.Favorite, null) }, label = { Text(stringResource(R.string.tab_donate), maxLines = 1) })
            }
        },
    ) { pad ->
        Surface(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> AppsTab(vm)
                1 -> CheckTab(vm)
                2 -> StorageTab(vm)
                3 -> SettingsTab(vm)
                else -> DonateTab()
            }
        }
    }
}

@Composable
fun CounterCard(count: Int, label: Int, color: androidx.compose.ui.graphics.Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = if (selected) 0.30f else 0.12f)),
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(count.toString(), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text(stringResource(label), color = color, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
fun AppsTab(vm: MainViewModel) {
    val apps = vm.apps
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableIntStateOf(-1) } // -1 hammasi, aks holda Level.ordinal
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.apps_intro), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.scanApps() }, enabled = !vm.scanning, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (vm.scanning) R.string.apps_scanning else R.string.apps_scan))
        }
        Spacer(Modifier.height(12.dp))
        if (vm.scanning && apps == null) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        } else if (apps != null) {
            val bad = apps.count { it.result.level == Level.BAD }
            val warn = apps.count { it.result.level == Level.WARN }
            val ok = apps.count { it.result.level == Level.OK }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CounterCard(bad, R.string.counter_bad, RedBad, filter == Level.BAD.ordinal, Modifier.weight(1f)) {
                    filter = if (filter == Level.BAD.ordinal) -1 else Level.BAD.ordinal
                }
                CounterCard(warn, R.string.counter_warn, AmberWarn, filter == Level.WARN.ordinal, Modifier.weight(1f)) {
                    filter = if (filter == Level.WARN.ordinal) -1 else Level.WARN.ordinal
                }
                CounterCard(ok, R.string.counter_ok, GreenOk, filter == Level.OK.ordinal, Modifier.weight(1f)) {
                    filter = if (filter == Level.OK.ordinal) -1 else Level.OK.ordinal
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.search_apps)) }, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            val q = query.trim().lowercase()
            val shown = apps.filter {
                (filter == -1 || it.result.level.ordinal == filter) &&
                    (q.isEmpty() || it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.packageName }) { AppRow(it) }
            }
        }
    }
}

@Composable
fun AppRow(item: AppResult) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val r = item.result
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LevelIcon(r.level, 24)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.label, fontWeight = FontWeight.SemiBold)
                    Text(item.packageName, style = MaterialTheme.typography.bodySmall)
                }
                Text(levelLabel(r.level), color = levelColor(r.level), fontWeight = FontWeight.Bold)
            }
            if (open) {
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.score_fmt, r.score), style = MaterialTheme.typography.bodySmall)
                r.flags.take(6).forEach { Text("• " + stringResource(it.reason), style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text(stringResource(R.string.btn_app_settings)) }
                    Button(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text(stringResource(R.string.btn_uninstall)) }
                }
            }
        }
    }
}

@Composable
fun CheckTab(vm: MainViewModel) {
    var link by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.checkFile(uri)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.check_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.check_hint), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.checking, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.btn_pick_file))
        }
        OutlinedTextField(
            value = link, onValueChange = { link = it }, label = { Text(stringResource(R.string.link_label)) },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(
            onClick = { vm.checkLink(link) }, enabled = !vm.checking && link.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(stringResource(R.string.btn_check_link)) }
        if (vm.checking) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.width(24.dp).height(24.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.checking))
            }
        }
        vm.error?.let { Text(it, color = RedBad) }
        vm.verdict?.let { VerdictCard(it) }
    }
}

@Composable
fun StorageTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val filesOn = remember(tick) { InstallGuard.hasFileAccess(ctx) }
    var confirm by remember { mutableStateOf<StoredApk?>(null) }
    val list = vm.stored

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(stringResource(R.string.storage_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.storage_intro), style = MaterialTheme.typography.bodySmall)
        if (!filesOn) {
            Text(stringResource(R.string.ig_files_off), color = AmberWarn, fontWeight = FontWeight.SemiBold)
            Button(onClick = { openFilesAccess(ctx) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.btn_turn_on)) }
        }
        Button(onClick = { vm.scanStorage() }, enabled = filesOn && !vm.storageScanning, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (vm.storageScanning) R.string.storage_scanning else R.string.storage_scan))
        }
        Text(stringResource(R.string.storage_deleted_count, vm.deletedFiles), style = MaterialTheme.typography.bodySmall)
        if (vm.storageScanning && list == null) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        } else if (list != null) {
            if (list.isEmpty()) {
                Text(stringResource(R.string.storage_none))
            } else {
                Text(
                    stringResource(R.string.storage_summary, list.size, list.count { it.result.level != Level.OK }),
                    fontWeight = FontWeight.SemiBold,
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.file.absolutePath }) { item ->
                        StoredRow(item) { confirm = item }
                    }
                }
            }
        }
    }
    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(stringResource(R.string.storage_delete_title)) },
            text = { Text(c.file.name) },
            confirmButton = {
                TextButton(onClick = { vm.deleteStored(c.file); confirm = null }) { Text(stringResource(R.string.btn_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text(stringResource(R.string.btn_cancel)) }
            },
        )
    }
}

@Composable
fun StoredRow(item: StoredApk, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val r = item.result
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LevelIcon(r.level, 24)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.file.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(
                        Formatter.formatFileSize(ctx, item.sizeBytes) + " • " + (item.file.parent ?: ""),
                        style = MaterialTheme.typography.bodySmall, maxLines = 1,
                    )
                }
                Text(levelLabel(r.level), color = levelColor(r.level), fontWeight = FontWeight.Bold)
            }
            if (open) {
                Spacer(Modifier.height(8.dp))
                r.packageName?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                r.flags.take(6).forEach { Text("• " + stringResource(it.reason), style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onDelete) { Text(stringResource(R.string.btn_delete)) }
            }
        }
    }
}

fun openFilesAccess(ctx: Context) {
    val i = if (Build.VERSION.SDK_INT >= 30) {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
    }
    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun SettingsTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    fun open(url: String) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(stringResource(R.string.tab_settings), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        InstallGuardSection(vm)
        SwitchRow(stringResource(R.string.settings_realtime), stringResource(R.string.settings_realtime_desc), vm.realtime) { vm.updateRealtime(it) }
        SwitchRow(stringResource(R.string.settings_periodic), stringResource(R.string.settings_periodic_desc), vm.periodic) { vm.updatePeriodic(it) }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.lang_title), fontWeight = FontWeight.Bold)
                val langs = listOf("auto" to stringResource(R.string.lang_auto), "uz" to "O‘zbekcha", "ru" to "Русский", "en" to "English")
                langs.forEach { (code, name) ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            if (vm.lang != code) { vm.updateLang(code); (ctx as? Activity)?.recreate() }
                        },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = vm.lang == code, onClick = {
                            if (vm.lang != code) { vm.updateLang(code); (ctx as? Activity)?.recreate() }
                        })
                        Text(name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.theme_title), fontWeight = FontWeight.Bold)
                val themes = listOf(R.string.theme_auto, R.string.theme_light, R.string.theme_dark)
                themes.forEachIndexed { i, res ->
                    Row(Modifier.fillMaxWidth().clickable { vm.updateTheme(i) }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = vm.theme == i, onClick = { vm.updateTheme(i) })
                        Text(stringResource(res))
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.contact_title2), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.contact_desc2), style = MaterialTheme.typography.bodySmall)
                Button(onClick = { open(Config.CHANNEL_URL) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contact_channel)) }
                OutlinedButton(onClick = { open(Config.ACCOUNT_URL) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contact_account) + " — @Developer_Toirov") }
                OutlinedButton(onClick = { open(Config.ADMIN_URL) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contact_admin) + " — @Safeapkguard") }
                OutlinedButton(onClick = { open(Config.BOT_URL) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.contact_bot) + " — @SafeApkGuardBot") }
            }
        }
        Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DonateTab() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(stringResource(R.string.donate_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.donate_desc), style = MaterialTheme.typography.bodyMedium)
        CardRow("Visa", Config.CARD_VISA)
        CardRow("Humo", Config.CARD_HUMO)
        Text(stringResource(R.string.donate_owner, Config.CARD_OWNER), fontWeight = FontWeight.SemiBold)
        Text(stringResource(R.string.donate_thanks), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun CardRow(name: String, number: String) {
    val ctx = LocalContext.current
    val copiedMsg = stringResource(R.string.copied)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(number, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleLarge)
            Button(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(name, number.replace(" ", "")))
                Toast.makeText(ctx, copiedMsg, Toast.LENGTH_SHORT).show()
            }) { Text(stringResource(R.string.btn_copy)) }
        }
    }
}

/** O‘rnatishdan himoya: ruxsatlar holati va rejim tanlash. */
@Composable
fun InstallGuardSection(vm: MainViewModel) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val askRead = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val accessOn = remember(tick) { InstallGuard.isAccessibilityOn(ctx) }
    val filesOn = remember(tick) { InstallGuard.hasFileAccess(ctx) }
    val blocked = remember(tick) { vm.blockedCount }

    fun open(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.ig_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.ig_desc), style = MaterialTheme.typography.bodySmall)

            Text(stringResource(if (accessOn) R.string.ig_access_on else R.string.ig_access_off),
                color = if (accessOn) GreenOk else AmberWarn, fontWeight = FontWeight.SemiBold)
            if (!accessOn) {
                Button(onClick = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_turn_on))
                }
                Text(stringResource(R.string.ig_restricted_hint), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = {
                    open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.btn_app_info)) }
            }

            Text(stringResource(if (filesOn) R.string.ig_files_on else R.string.ig_files_off),
                color = if (filesOn) GreenOk else AmberWarn, fontWeight = FontWeight.SemiBold)
            if (!filesOn) {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 30) openFilesAccess(ctx) else askRead.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.btn_turn_on)) }
            }

            Text(stringResource(R.string.ig_mode_title), fontWeight = FontWeight.SemiBold)
            val modes = listOf(R.string.ig_mode_0, R.string.ig_mode_1, R.string.ig_mode_2, R.string.ig_mode_3)
            modes.forEachIndexed { i, res ->
                Row(Modifier.fillMaxWidth().clickable { vm.updateBlockMode(i) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = vm.blockMode == i, onClick = { vm.updateBlockMode(i) })
                    Text(stringResource(res))
                }
            }
            Text(stringResource(R.string.ig_blocked_count, blocked), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
