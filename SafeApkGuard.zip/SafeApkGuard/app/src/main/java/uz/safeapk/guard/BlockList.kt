package uz.safeapk.guard

/** Foydalanuvchi o‘zi kiritgan «o‘rnatish taqiqlangan» ilova nomlari bilan solishtirish. */
object BlockList {
    const val MAX_NAMES = 50

    private fun isWordChar(c: Char) = c.isLetterOrDigit()

    fun clean(raw: String): String = raw.trim().replace(Regex("\\s+"), " ").take(40)

    /**
     * [texts] — normText() dan o‘tgan ekran matnlari. Topilsa, ro‘yxatdagi nom qaytariladi.
     * loose=true: nom matn ichida alohida so‘z sifatida bo‘lsa ham mos (o‘rnatuvchi oynasi, ilova nomi);
     * loose=false: matn nomning o‘zi yoki «Nom — ...» ko‘rinishidagi qisqa sarlavha bo‘lsa (do‘kon ekrani).
     */
    fun find(names: Set<String>, texts: List<String>, loose: Boolean): String? {
        for (name in names) {
            val n = normText(name).trim()
            if (n.length < 2) continue
            for (t in texts) if (matches(n, t, loose)) return name
        }
        return null
    }

    private fun matches(n: String, t: String, loose: Boolean): Boolean {
        if (t == n) return true
        if (loose) {
            var from = 0
            while (true) {
                val i = t.indexOf(n, from)
                if (i < 0) return false
                val before = i == 0 || !isWordChar(t[i - 1])
                val after = i + n.length >= t.length || !isWordChar(t[i + n.length])
                if (before && after) return true
                from = i + 1
            }
        }
        return t.length <= n.length + 30 && t.startsWith(n) && !isWordChar(t[n.length])
    }

    fun labelMatches(names: Set<String>, label: String): String? =
        find(names, listOf(normText(label)), loose = true)
}
