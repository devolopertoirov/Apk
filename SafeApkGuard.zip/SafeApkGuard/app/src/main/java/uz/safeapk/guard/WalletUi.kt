package uz.safeapk.guard

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Xabar/xato qatori (yopish tugmasi bilan). */
@Composable
fun WalletMessage(w: WalletViewModel) {
    val m = w.message ?: return
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(m, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = { w.message = null }) { Text(stringResource(R.string.btn_ok)) }
        }
    }
}

@Composable
fun WalletTab(w: WalletViewModel) {
    var adminOpen by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(w.loggedIn) {
        if (w.loggedIn) {
            w.refreshAll()
            w.loadWithdrawals()
            while (true) { // ekran ochiq turguncha: har 15 soniyada kanal obunasi tekshiriladi
                w.claimChannels()
                delay(15_000)
            }
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.wallet_title), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        WalletMessage(w)
        if (!w.loggedIn) {
            LoginCard(w)
        } else if (adminOpen && w.me?.admin == true) {
            AdminSection(w) { adminOpen = false }
        } else {
            val me = w.me
            if (me == null) {
                Text(stringResource(R.string.wallet_loading), style = MaterialTheme.typography.bodyMedium)
            } else {
                BalanceCard(me)
                DailyCard(w, me)
                ChannelsCard(w, me)
                WithdrawCard(w, me)
                if (me.admin) {
                    Button(onClick = { adminOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.admin_open))
                    }
                }
            }
            OutlinedButton(onClick = { w.logout() }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.btn_logout))
            }
        }
    }
}

@Composable
fun LoginCard(w: WalletViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.wallet_login_desc), style = MaterialTheme.typography.bodyMedium)
            if (w.loginWaiting) {
                Text(stringResource(R.string.login_waiting), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { w.cancelLogin() }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_cancel))
                }
            } else {
                Button(onClick = { w.startLogin() }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.btn_login))
                }
            }
        }
    }
}

@Composable
fun BalanceCard(me: Me) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(me.name, style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.wallet_balance, me.coins), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (me.vip) Text(stringResource(R.string.wallet_vip), style = MaterialTheme.typography.bodySmall)
            if (me.banned) Text(stringResource(R.string.err_banned), style = MaterialTheme.typography.bodySmall)
            Text(
                stringResource(R.string.wallet_rates, me.loginBonusAmount, me.dailyBonus, me.channelBonus),
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
fun DailyCard(w: WalletViewModel, me: Me) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (me.dailyLeft > 0) {
                Text(
                    stringResource(R.string.daily_wait_fmt, (me.dailyLeft / 3600).toInt(), ((me.dailyLeft % 3600) / 60).toInt()),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Button(onClick = { w.daily() }, enabled = me.dailyLeft <= 0L, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.btn_daily, me.dailyBonus))
            }
        }
    }
}

@Composable
fun ChannelsCard(w: WalletViewModel, me: Me) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.channels_title, me.channelBonus), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.channels_desc, me.channelBonus), style = MaterialTheme.typography.bodySmall)
            if (me.chanLocked) Text(stringResource(R.string.channels_locked), style = MaterialTheme.typography.bodySmall)
            if (w.channels.isEmpty()) Text(stringResource(R.string.channels_empty), style = MaterialTheme.typography.bodySmall)
            w.channels.forEach { ch ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ch.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    if (ch.rewarded) {
                        Text(stringResource(R.string.channel_done), style = MaterialTheme.typography.bodySmall)
                    } else {
                        OutlinedButton(onClick = {
                            if (ch.url.isNotBlank()) {
                                runCatching {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ch.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                            }
                        }) { Text(stringResource(R.string.btn_subscribe)) }
                    }
                }
            }
        }
    }
}

@Composable
fun WithdrawCard(w: WalletViewModel, me: Me) {
    var amount by remember { mutableStateOf("") }
    var card by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.withdraw_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (me.vip) {
                Text(stringResource(R.string.wallet_vip), style = MaterialTheme.typography.bodySmall)
            } else {
                Text(stringResource(R.string.withdraw_desc, me.minWithdraw, me.dayCap), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it.filter(Char::isDigit).take(9) }, singleLine = true,
                    label = { Text(stringResource(R.string.withdraw_amount_hint)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = card, onValueChange = { card = it.filter { c -> c.isDigit() || c == ' ' }.take(19) }, singleLine = true,
                    label = { Text(stringResource(R.string.withdraw_card_hint)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                )
                Button(onClick = {
                    w.withdraw(amount, card) { ok -> if (ok) { amount = ""; card = "" } }
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.btn_withdraw)) }
            }
            if (w.withdrawals.isNotEmpty()) {
                Text(stringResource(R.string.withdraw_history), style = MaterialTheme.typography.labelLarge)
                w.withdrawals.forEach { x ->
                    val st = when (x.status) {
                        "paid" -> R.string.wd_paid
                        "rejected" -> R.string.wd_rejected
                        else -> R.string.wd_pending
                    }
                    Text("#${x.id} · ${x.amount} · ${x.card} · ${stringResource(st)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ============================================================ admin (ilova ichida)
@Composable
fun AdminSection(w: WalletViewModel, onBack: () -> Unit) {
    var idText by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        w.adminLoadStats()
        w.adminLoadWd()
        w.adminLoadCh()
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.admin_back)) }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.admin_stats), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                w.adminStats.forEach { (k, v) -> Text("$k: $v", style = MaterialTheme.typography.bodySmall) }
                TextButton(onClick = { w.adminLoadStats() }) { Text(stringResource(R.string.diag_refresh)) }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.admin_user), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = idText, onValueChange = { idText = it.filter(Char::isDigit).take(15) }, singleLine = true,
                        label = { Text(stringResource(R.string.admin_id_hint)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { w.adminFind(idText) }) { Text(stringResource(R.string.btn_find)) }
                }
                w.adminUser?.let { u ->
                    Text("${u.name} (${u.id})", fontWeight = FontWeight.SemiBold)
                    Text("coin: ${u.coins} · VIP: ${u.vip} · ban: ${u.banned}", style = MaterialTheme.typography.bodySmall)
                    if (u.blocked.isNotEmpty()) Text(u.blocked.joinToString(", "), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { w.adminCoins(100) }) { Text("+100") }
                        OutlinedButton(onClick = { w.adminCoins(1000) }) { Text("+1000") }
                        OutlinedButton(onClick = { w.adminCoins(-100) }) { Text("−100") }
                        OutlinedButton(onClick = { w.adminCoins(-1000) }) { Text("−1000") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { w.adminVip(!u.vip) }) {
                            Text(stringResource(if (u.vip) R.string.btn_vip_off else R.string.btn_vip_on))
                        }
                        OutlinedButton(onClick = { w.adminBan(!u.banned) }) {
                            Text(stringResource(if (u.banned) R.string.btn_unban else R.string.btn_ban))
                        }
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.admin_wd), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (w.adminWd.isEmpty()) Text(stringResource(R.string.admin_empty), style = MaterialTheme.typography.bodySmall)
                w.adminWd.forEach { x ->
                    Text("#${x.id} · ${x.name} (${x.userId})\n${x.amount} · ${x.card}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { w.adminWdAction(x.id, true) }) { Text(stringResource(R.string.btn_paid)) }
                        OutlinedButton(onClick = { w.adminWdAction(x.id, false) }) { Text(stringResource(R.string.btn_reject)) }
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.admin_channels), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.admin_ch_note), style = MaterialTheme.typography.bodySmall)
                if (w.adminCh.isEmpty()) Text(stringResource(R.string.admin_empty), style = MaterialTheme.typography.bodySmall)
                w.adminCh.forEach { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = { w.adminChToggle(c.id, !c.enabled) }) {
                            Text(stringResource(if (c.enabled) R.string.btn_disable else R.string.btn_enable))
                        }
                        TextButton(onClick = { w.adminChDelete(c.id) }) { Text(stringResource(R.string.blocklist_remove)) }
                    }
                }
            }
        }
    }
}

// ============================================================ sozlamalar bo‘limlari
/** Foydalanuvchi o‘rnatilishini taqiqlagan ilova nomlari (pullik slot, server bilan sinxron). */
@Composable
fun BlockedAppsSection(w: WalletViewModel) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val emptyDiag = stringResource(R.string.diag_empty)
    var dbg by remember { mutableStateOf(Prefs(ctx).storeDebug) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.blocklist_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.blocklist_desc), style = MaterialTheme.typography.bodySmall)
            if (!w.loggedIn) {
                Text(stringResource(R.string.blocked_login_needed), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            } else {
                val price = w.me?.let { if (it.vip) 0 else it.slotPrice } ?: 125
                Text(stringResource(R.string.blocklist_price, price), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            }
            WalletMessage(w)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f), singleLine = true,
                    label = { Text(stringResource(R.string.blocklist_hint)) },
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { w.addBlocked(text) { ok -> if (ok) text = "" } }) { Text(stringResource(R.string.blocklist_add)) }
            }
            if (w.blocked.isEmpty()) {
                Text(stringResource(R.string.blocklist_empty), style = MaterialTheme.typography.bodySmall)
            }
            w.blocked.forEach { n ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { w.removeBlocked(n) }) { Text(stringResource(R.string.blocklist_remove)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.blocklist_diag, dbg.ifBlank { emptyDiag }), Modifier.weight(1f),
                    style = MaterialTheme.typography.labelSmall,
                )
                TextButton(onClick = { dbg = Prefs(ctx).storeDebug }) { Text(stringResource(R.string.diag_refresh)) }
            }
        }
    }
}

/** Bot serveri manzili (Termux + tunnel bo‘lsa, manzil o‘zgarganda shu yerdan yangilanadi). */
@Composable
fun ServerCard(w: WalletViewModel) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(Prefs(ctx).apiBase.ifBlank { Config.API_BASE }) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.server_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.server_desc), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = url, onValueChange = { url = it.trim() }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.server_hint)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            )
            Button(onClick = {
                Prefs(ctx).apiBase = url
                w.pingServer()
            }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.server_save)) }
            WalletMessage(w)
        }
    }
}
