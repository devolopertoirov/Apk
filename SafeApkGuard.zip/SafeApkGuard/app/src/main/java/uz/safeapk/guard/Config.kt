package uz.safeapk.guard

/** Bog‘lanish havolalari va xayriya (donat) rekvizitlari. */
object Config {
    const val CHANNEL_URL = "https://t.me/devoloper_toirov"
    const val ACCOUNT_URL = "https://t.me/Developer_Toirov"
    const val ADMIN_URL = "https://t.me/Safeapkguard"
    const val BOT_URL = "https://t.me/SafeApkGuardBot"

    const val CARD_VISA = "4231 2000 9233 9547"
    const val CARD_HUMO = "9860 1666 5435 7473"
    const val CARD_OWNER = "Diyorbek T."
}
