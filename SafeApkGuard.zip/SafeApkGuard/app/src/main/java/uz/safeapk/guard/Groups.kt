package uz.safeapk.guard

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.annotation.StringRes
import java.io.File

/**
 * Majburiy bloklash guruhi. names — do‘kon va o‘rnatuvchi oynasida ko‘rinadigan tanilgan nomlar,
 * packages — aniq paket nomi yoki «.» bilan tugagan prefiks (o‘rnatilgandan keyin tekshiriladi),
 * categories — ilova o‘zi e’lon qilgan toifa (ApplicationInfo.CATEGORY_*).
 */
data class AppGroup(
    val id: String,
    @StringRes val title: Int,
    @StringRes val desc: Int,
    val categories: Set<Int>,
    val names: Set<String>,
    val packages: List<String>,
)

object Groups {
    val ALL: List<AppGroup> = listOf(
        AppGroup(
            "games", R.string.group_games, R.string.group_games_desc, setOf(ApplicationInfo.CATEGORY_GAME),
            setOf(
                "pubg mobile", "pubg", "free fire", "garena free fire", "roblox", "minecraft", "brawl stars",
                "clash of clans", "clash royale", "among us", "subway surfers", "candy crush", "mobile legends",
                "call of duty", "genshin impact", "fortnite", "standoff 2", "block blast", "stumble guys",
                "8 ball pool", "ludo king", "coin master", "hill climb racing", "temple run", "city block",
            ),
            listOf(
                "com.dts.freefireth", "com.dts.freefiremax", "com.tencent.ig", "com.pubg.imobile", "com.roblox.client",
                "com.mojang.minecraftpe", "com.supercell.", "com.king.", "com.kiloo.subwaysurf", "com.axlebolt.standoff2",
                "com.activision.callofduty.", "com.innersloth.spacemafia", "com.miHoYo.GenshinImpact", "com.moonton.mobilehero",
            ),
        ),
        AppGroup(
            "social", R.string.group_social, R.string.group_social_desc, emptySet(),
            setOf("instagram", "tiktok", "facebook", "snapchat", "twitter", "vk", "vkontakte", "likee", "pinterest", "reddit", "odnoklassniki"),
            listOf(
                "com.instagram.android", "com.instagram.barcelona", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
                "com.facebook.katana", "com.snapchat.android", "com.twitter.android", "com.vkontakte.android", "ru.ok.android",
                "com.pinterest", "com.reddit.frontpage",
            ),
        ),
        AppGroup(
            "betting", R.string.group_betting, R.string.group_betting_desc, emptySet(),
            setOf(
                "1xbet", "melbet", "mostbet", "linebet", "betwinner", "1win", "pin-up", "pin up", "parimatch", "fonbet",
                "betboom", "bet365", "22bet", "megapari", "888starz", "olimpbet", "casino", "kazino", "vavada", "lucky jet", "aviator",
            ),
            emptyList(),
        ),
        AppGroup(
            "video", R.string.group_video, R.string.group_video_desc, emptySet(),
            setOf("youtube", "netflix", "twitch", "kinopoisk", "okko", "ivi", "hbo max", "disney+"),
            listOf("com.netflix.mediaclient", "tv.twitch.android.app"),
        ),
    )

    fun enabled(ctx: Context): List<AppGroup> {
        val on = Prefs(ctx).enabledGroups
        return ALL.filter { it.id in on }
    }

    /** Yoqilgan guruhlarning ekran nomlari (do‘kon / o‘rnatuvchi oynasini solishtirish uchun). */
    fun enabledNames(ctx: Context): Set<String> = enabled(ctx).flatMap { it.names }.toSet()

    fun groupOfName(ctx: Context, hit: String): AppGroup? {
        val h = normText(hit)
        return enabled(ctx).firstOrNull { g -> g.names.any { normText(it) == h } }
    }

    @Suppress("DEPRECATION")
    private fun isGameFlag(ai: ApplicationInfo) = ai.flags and ApplicationInfo.FLAG_IS_GAME != 0

    private fun matchApp(ctx: Context, pkg: String, label: String, ai: ApplicationInfo?): AppGroup? {
        for (g in enabled(ctx)) {
            if (ai != null) {
                if (ai.category in g.categories) return g
                if (g.id == "games" && isGameFlag(ai)) return g
            }
            if (g.packages.any { pkg == it || (it.endsWith(".") && pkg.startsWith(it)) }) return g
            if (label.isNotBlank() && BlockList.labelMatches(g.names, label) != null) return g
        }
        return null
    }

    /** O‘rnatilgan ilova guruhga kiradimi (tizim ilovalari va o‘zimiz hisobga olinmaydi). */
    fun matchInstalled(ctx: Context, pkg: String): AppGroup? {
        if (pkg == ctx.packageName || Prefs(ctx).enabledGroups.isEmpty()) return null
        val pm = ctx.packageManager
        val ai = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return null
        if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) return null
        val label = runCatching { ai.loadLabel(pm).toString() }.getOrDefault(pkg)
        return matchApp(ctx, pkg, label, ai)
    }

    /** Hali o‘rnatilmagan APK fayl guruhga kiradimi (faqat .apk: toifa fayl ichidan o‘qiladi). */
    fun matchArchive(ctx: Context, file: File, pkg: String, label: String): AppGroup? {
        if (Prefs(ctx).enabledGroups.isEmpty()) return null
        val ai = if (file.name.lowercase().endsWith(".apk")) {
            runCatching { ctx.packageManager.getPackageArchiveInfo(file.absolutePath, 0)?.applicationInfo }.getOrNull()
        } else null
        return matchApp(ctx, pkg, label, ai)
    }
}
