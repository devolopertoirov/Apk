package uz.safeapk.guard

import android.app.Application

class GuardApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        NewAppChecker.schedule(this, Prefs(this).periodic)
        // Yarim yo‘lda qolib ketgan vaqtinchalik nusxalarni tozalash
        Thread {
            runCatching {
                val cutoff = System.currentTimeMillis() - 10 * 60_000L
                cacheDir.listFiles()?.forEach { f ->
                    val n = f.name
                    if ((n.startsWith("scan_") || n.startsWith("unwrap_")) && n.endsWith(".apk") && f.lastModified() < cutoff) f.delete()
                }
            }
        }.start()
    }
}
