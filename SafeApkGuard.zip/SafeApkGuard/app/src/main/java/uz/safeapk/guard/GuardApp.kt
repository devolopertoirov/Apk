package uz.safeapk.guard

import android.app.Application

class GuardApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        NewAppChecker.schedule(this, Prefs(this).periodic)
    }
}
