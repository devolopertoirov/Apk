package uz.safeapk.guard.analysis

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

/**
 * APK tahlili. AndroidManifest.xml ni Android tizimining o‘zi (PackageManager) o‘qiydi,
 * qolgan belgilar (yashirin dastur, Telegram-bot, debug imzo) ZIP ichidan qidiriladi.
 */
object ApkAnalyzer {
    const val MANIFEST_FLAGS =
        PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS

    private val PERM_FLAGS = mapOf(
        "android.permission.READ_SMS" to Flag.SMS_READ,
        "android.permission.RECEIVE_SMS" to Flag.SMS_READ,
        "android.permission.RECEIVE_MMS" to Flag.SMS_READ,
        "android.permission.RECEIVE_WAP_PUSH" to Flag.SMS_READ,
        "android.permission.SEND_SMS" to Flag.SMS_SEND,
        "android.permission.WRITE_SMS" to Flag.SMS_SEND,
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to Flag.ACCESS,
        "android.permission.BIND_DEVICE_ADMIN" to Flag.DEVADMIN,
        "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" to Flag.NOTIF,
        "android.permission.REQUEST_INSTALL_PACKAGES" to Flag.INSTALL,
        "android.permission.SYSTEM_ALERT_WINDOW" to Flag.OVERLAY,
        "android.permission.READ_CALL_LOG" to Flag.CALLLOG,
    )
    private val DEX_NAME = Regex("classes\\d*\\.dex")
    private val DEX_MAGIC = byteArrayOf(0x64, 0x65, 0x78, 0x0A) // "dex\n"
    private val TG_BYTES = "api.telegram.org".toByteArray()
    private val DEBUG_BYTES = "Android Debug".toByteArray()

    /** Manifestdagi so‘ralgan ruxsatlar va komponentlarga bog‘langan ruxsatlar bo‘yicha belgilar. */
    fun flagsFromPackageInfo(pi: PackageInfo): MutableSet<Flag> {
        val out = mutableSetOf<Flag>()
        pi.requestedPermissions?.forEach { p -> PERM_FLAGS[p]?.let { out += it } }
        pi.services?.forEach { s -> s.permission?.let { p -> PERM_FLAGS[p]?.let { out += it } } }
        pi.receivers?.forEach { r -> r.permission?.let { p -> PERM_FLAGS[p]?.let { out += it } } }
        return out
    }

    /** Foydalanuvchi bergan APK faylni tekshiradi (1-bosqich: manifest, keyin ZIP belgilari). */
    fun analyzeFile(ctx: Context, file: File, sha: String?): ScanResult {
        val pm = ctx.packageManager
        val pi = Compat.archiveInfo(pm, file.absolutePath, MANIFEST_FLAGS)
        val flags = mutableSetOf<Flag>()
        var label: String? = null
        var pkg: String? = null
        if (pi == null) {
            flags += Flag.BROKEN
        } else {
            pkg = pi.packageName
            flags += flagsFromPackageInfo(pi)
            pi.applicationInfo?.let { ai ->
                ai.sourceDir = file.absolutePath
                ai.publicSourceDir = file.absolutePath
                label = runCatching { ai.loadLabel(pm).toString() }.getOrNull()
            }
        }
        flags += scanZip(file)
        return Scoring.build(flags, 0, pkg, label, sha, valid = pi != null)
    }

    /** .apks/.xapk/.apkm kabi arxivlardan asosiy APK ni vaqtincha chiqarib oladi (topilmasa null). */
    fun unwrap(file: File, tmpDir: File): File? = try {
        ZipFile(file).use { zf ->
            val apks = zf.entries().toList().filter {
                !it.isDirectory && it.name.lowercase().endsWith(".apk") && it.size in 1L..(300L * 1024 * 1024)
            }
            fun base(e: java.util.zip.ZipEntry) = e.name.substringAfterLast('/').lowercase()
            val pick = apks.firstOrNull { base(it) == "base.apk" }
                ?: apks.firstOrNull { !base(it).startsWith("split_") && !base(it).startsWith("config.") }
                ?: apks.firstOrNull()
            if (pick == null) null else {
                val out = File(tmpDir, "unwrap_${System.nanoTime()}.apk")
                zf.getInputStream(pick).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                out
            }
        }
    } catch (e: Exception) {
        null
    }

    /** Oddiy APK ni ham, arxiv (.apks/.xapk) ichidagi APK ni ham tekshiradi. */
    fun analyzeAny(ctx: Context, file: File, sha: String?): ScanResult {
        if (Compat.archiveInfo(ctx.packageManager, file.absolutePath, 0) != null) return analyzeFile(ctx, file, sha)
        val inner = unwrap(file, ctx.cacheDir) ?: return analyzeFile(ctx, file, sha)
        try {
            return analyzeFile(ctx, inner, sha)
        } finally {
            inner.delete()
        }
    }

    /** ZIP ichidan: yashirin APK/DEX, dex ichida Telegram bot API, debug sertifikat, arxiv-bomba. */
    fun scanZip(file: File): Set<Flag> {
        val out = mutableSetOf<Flag>()
        try {
            ZipFile(file).use { zf ->
                val entries = zf.entries().toList()
                if (entries.sumOf { maxOf(it.size, 0L) } > 800L * 1024 * 1024) out += Flag.BOMB
                var checked = 0
                for (e in entries) {
                    if (e.isDirectory) continue
                    val low = e.name.lowercase()
                    val isDex = DEX_NAME.matches(low)
                    if (low.endsWith(".apk") || ((low.endsWith(".dex") || low.endsWith(".jar")) && !isDex)) {
                        out += Flag.PAYLOAD
                    } else if ((low.startsWith("assets/") || low.startsWith("res/raw/")) &&
                        e.size in 1001L..(12L * 1024 * 1024) && checked < 30
                    ) {
                        checked++
                        runCatching {
                            zf.getInputStream(e).use { s ->
                                val head = ByteArray(4)
                                if (s.read(head) == 4 && head.contentEquals(DEX_MAGIC)) out += Flag.PAYLOAD
                            }
                        }
                    }
                    if (Flag.BOMB !in out && isDex && e.size <= 40L * 1024 * 1024) {
                        runCatching { zf.getInputStream(e).use { if (containsBytes(it, TG_BYTES)) out += Flag.TG } }
                    }
                    if (low.startsWith("meta-inf/") &&
                        (low.endsWith(".rsa") || low.endsWith(".dsa") || low.endsWith(".ec")) && e.size < 200_000
                    ) {
                        runCatching { zf.getInputStream(e).use { if (containsBytes(it, DEBUG_BYTES)) out += Flag.DEBUG } }
                    }
                }
            }
        } catch (e: Exception) {
            out += Flag.BROKEN
        }
        return out
    }

    private fun containsBytes(input: InputStream, pat: ByteArray): Boolean {
        val chunk = 64 * 1024
        val buf = ByteArray(chunk + pat.size)
        var carry = 0
        while (true) {
            val n = input.read(buf, carry, chunk)
            if (n < 0) return false
            val len = carry + n
            if (indexOf(buf, len, pat) >= 0) return true
            carry = minOf(pat.size - 1, len)
            System.arraycopy(buf, len - carry, buf, 0, carry)
        }
    }

    private fun indexOf(buf: ByteArray, len: Int, pat: ByteArray): Int {
        var i = 0
        while (i <= len - pat.size) {
            var j = 0
            while (j < pat.size && buf[i + j] == pat[j]) j++
            if (j == pat.size) return i
            i++
        }
        return -1
    }
}
