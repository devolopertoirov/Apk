package uz.safeapk.guard

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

/**
 * «Muzlatilgan» ilova o‘rniga chiqadigan bo‘sh oq ekran. Hech qanday matn, tugma yoki belgi yo‘q — ilova
 * osilib qolgandek ko‘rinadi. Orqaga tugmasi e’tiborga olinmaydi (ekran o‘zgarmaydi); uy tugmasi/jest odatdagidek
 * ishlaydi, shunda foydalanuvchi telefonni oddiy qaytarib beradi.
 */
class FreezeActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this) { /* orqaga tugmasi hech narsa qilmaydi */ }
        setContent {
            Surface(Modifier.fillMaxSize(), color = Color.White) {
                Box(Modifier.fillMaxSize())
            }
        }
    }

    // Boshqa ilova ustiga yana shu ekran kerak bo‘lsa (masalan, foydalanuvchi qayta ochsa), eski nusxa qayta ishlatiladi
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
    }
}
