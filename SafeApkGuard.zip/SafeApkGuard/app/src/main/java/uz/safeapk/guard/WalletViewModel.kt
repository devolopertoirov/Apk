package uz.safeapk.guard

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Me(
    val userId: Long, val name: String, val coins: Int, val vip: Boolean, val admin: Boolean, val banned: Boolean,
    val chanLocked: Boolean, val dailyLeft: Long, val loginBonus: Boolean, val slotPrice: Int, val minWithdraw: Int,
    val dayCap: Int, val loginBonusAmount: Int, val dailyBonus: Int, val channelBonus: Int,
)

data class ChannelItem(val chatId: Long, val title: String, val url: String, val rewarded: Boolean)
data class WdItem(val id: Int, val userId: Long, val name: String, val amount: Int, val card: String, val status: String)
data class AdminUser(val id: Long, val name: String, val coins: Int, val vip: Boolean, val banned: Boolean, val blocked: List<String>)
data class AdminChannel(val id: Int, val title: String, val enabled: Boolean)

private fun JSONObject.toMe() = Me(
    userId = optLong("user_id"), name = optString("name"), coins = optInt("coins"), vip = optBoolean("vip"),
    admin = optBoolean("admin"), banned = optBoolean("banned"), chanLocked = optBoolean("chan_locked"),
    dailyLeft = optLong("daily_left"), loginBonus = optBoolean("login_bonus"), slotPrice = optInt("slot_price", 125),
    minWithdraw = optInt("min_withdraw", 10000), dayCap = optInt("day_cap", 100000),
    loginBonusAmount = optInt("login_bonus_amount", 50), dailyBonus = optInt("daily_bonus", 2),
    channelBonus = optInt("channel_bonus", 5),
)

private fun JSONArray?.toStringList(): List<String> =
    if (this == null) emptyList() else (0 until length()).map { optString(it) }

private fun JSONArray?.toChannels(): List<ChannelItem> =
    if (this == null) emptyList() else (0 until length()).map {
        val o = getJSONObject(it)
        ChannelItem(o.optLong("chat_id"), o.optString("title"), o.optString("url"), o.optBoolean("rewarded"))
    }

private fun JSONArray?.toWd(): List<WdItem> =
    if (this == null) emptyList() else (0 until length()).map {
        val o = getJSONObject(it)
        WdItem(o.optInt("id"), o.optLong("user_id"), o.optString("name"), o.optInt("amount"), o.optString("card"), o.optString("status"))
    }

private fun JSONObject.toAdminUser() = AdminUser(
    optLong("user_id"), optString("name"), optInt("coins"), optBoolean("vip"), optBoolean("banned"),
    optJSONArray("blocked").toStringList(),
)

/** Guard Coin: kirish (Telegram bot orqali), hamyon, kanallar, bloklangan ilovalar, yechish va admin. */
class WalletViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val ctx get() = getApplication<Application>()

    var loggedIn by mutableStateOf(prefs.token.isNotEmpty())
        private set
    var me by mutableStateOf<Me?>(null)
        private set
    var loginWaiting by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
    var channels by mutableStateOf<List<ChannelItem>>(emptyList())
        private set
    var withdrawals by mutableStateOf<List<WdItem>>(emptyList())
        private set
    var blocked by mutableStateOf(prefs.blockedNames.sortedBy { it.lowercase() })
        private set

    var adminStats by mutableStateOf<Map<String, Long>>(emptyMap())
        private set
    var adminUser by mutableStateOf<AdminUser?>(null)
        private set
    var adminWd by mutableStateOf<List<WdItem>>(emptyList())
        private set
    var adminCh by mutableStateOf<List<AdminChannel>>(emptyList())
        private set

    private var loginJob: Job? = null

    // ------------------------------------------------------------ umumiy
    private fun errorText(e: Api.ApiError): String {
        val x = e.extra
        return when (e.code) {
            "no_server", "network", "bad_response", "server" -> ctx.getString(R.string.err_network)
            "auth" -> ctx.getString(R.string.err_auth)
            "rate_limit" -> ctx.getString(R.string.err_rate)
            "banned" -> ctx.getString(R.string.err_banned)
            "no_coins" -> ctx.getString(R.string.err_no_coins)
            "exists" -> ctx.getString(R.string.err_exists)
            "bad_name" -> ctx.getString(R.string.err_bad_name)
            "limit" -> ctx.getString(R.string.err_limit)
            "bad_card" -> ctx.getString(R.string.err_card)
            "pending_exists" -> ctx.getString(R.string.err_pending)
            "vip_no_withdraw" -> ctx.getString(R.string.err_vip)
            "login_required" -> ctx.getString(R.string.err_login_required)
            "forbidden" -> ctx.getString(R.string.err_forbidden)
            "min" -> ctx.getString(R.string.err_min, x?.optInt("min") ?: 0)
            "day_cap" -> ctx.getString(R.string.err_daycap, x?.optInt("left") ?: 0)
            else -> ctx.getString(R.string.err_generic, e.code)
        }
    }

    private suspend fun req(
        method: String, path: String, body: JSONObject? = null, auth: Boolean = true, quiet: Boolean = false,
    ): JSONObject? = try {
        Api.call(ctx, method, path, body, auth)
    } catch (e: Api.ApiError) {
        if (e.code == "auth") signOutLocal()
        if (!quiet) message = errorText(e)
        null
    }

    private fun signOutLocal() {
        prefs.token = ""
        prefs.blockedNames = emptySet()
        loggedIn = false
        me = null
        blocked = emptyList()
        channels = emptyList()
        withdrawals = emptyList()
    }

    private fun syncBlocked(names: List<String>) {
        prefs.blockedNames = names.toSet()
        blocked = names.sortedBy { it.lowercase() }
    }

    private fun openLink(link: String) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun deviceId(): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        val base = if (aid.isNotEmpty()) aid else prefs.fallbackDevice
        return MessageDigest.getInstance("SHA-256").digest("guard:$base".toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun pingServer() {
        viewModelScope.launch {
            val r = req("GET", "/api/ping", auth = false)
            if (r != null) message = ctx.getString(R.string.server_ok)
        }
    }

    // ------------------------------------------------------------ kirish
    fun startLogin() {
        if (loginWaiting) return
        loginJob = viewModelScope.launch {
            loginWaiting = true
            message = null
            val r = req("POST", "/api/login/start", JSONObject().put("device", deviceId()), auth = false)
            val link = r?.optString("link").orEmpty()
            val code = r?.optString("code").orEmpty()
            if (link.isEmpty() || code.isEmpty()) {
                loginWaiting = false
                return@launch
            }
            openLink(link)
            var tries = 0
            while (loginWaiting && tries < 300) { // 2 soniyadan 10 daqiqagacha
                delay(2000)
                tries++
                val p = req("GET", "/api/login/poll?code=" + Uri.encode(code), auth = false, quiet = true) ?: continue
                when (p.optString("status")) {
                    "done" -> {
                        prefs.token = p.optString("token")
                        loggedIn = true
                        me = p.optJSONObject("me")?.toMe()
                        loginWaiting = false
                        refreshAll()
                        return@launch
                    }
                    "expired" -> {
                        loginWaiting = false
                        message = ctx.getString(R.string.login_expired)
                        return@launch
                    }
                }
            }
            loginWaiting = false
        }
    }

    fun cancelLogin() {
        loginWaiting = false
        loginJob?.cancel()
    }

    fun logout() {
        viewModelScope.launch {
            req("POST", "/api/logout", JSONObject(), quiet = true)
            signOutLocal()
        }
    }

    // ------------------------------------------------------------ hamyon
    fun refreshAll() {
        if (!loggedIn) return
        viewModelScope.launch {
            val r = req("GET", "/api/me", quiet = true) ?: return@launch
            me = r.optJSONObject("me")?.toMe()
            r.optJSONArray("blocked")?.let { syncBlocked(it.toStringList()) }
            claimBonusIfNeeded()
        }
    }

    private suspend fun claimBonusIfNeeded() {
        val m = me ?: return
        if (m.loginBonus || History.all(ctx).isEmpty()) return
        val r = req("POST", "/api/claim/first_scan", JSONObject(), quiet = true) ?: return
        r.optJSONObject("me")?.let { me = it.toMe() }
        val g = r.optInt("granted")
        if (g > 0) message = ctx.getString(R.string.msg_bonus, g)
    }

    fun daily() {
        viewModelScope.launch {
            val r = req("POST", "/api/daily/begin", JSONObject()) ?: return@launch
            val left = r.optLong("seconds_left")
            if (left > 0) {
                message = ctx.getString(R.string.daily_wait_fmt, (left / 3600).toInt(), ((left % 3600) / 60).toInt())
                return@launch
            }
            openLink(r.optString("link"))
        }
    }

    fun loadChannels() {
        viewModelScope.launch {
            val r = req("GET", "/api/channels", quiet = true) ?: return@launch
            channels = r.optJSONArray("channels").toChannels()
            r.optJSONObject("me")?.let { me = it.toMe() }
        }
    }

    /** Kanal a‘zoligini serverda tekshirtiradi (+5 / −5). Wallet ekrani ochiq turganda har 15 soniyada chaqiriladi. */
    fun claimChannels() {
        viewModelScope.launch {
            val r = req("POST", "/api/channels/claim", JSONObject(), quiet = true) ?: return@launch
            channels = r.optJSONArray("channels").toChannels()
            r.optJSONObject("me")?.let { me = it.toMe() }
        }
    }

    fun addBlocked(raw: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            if (!loggedIn) {
                message = ctx.getString(R.string.err_login_required)
                onDone(false)
                return@launch
            }
            val r = req("POST", "/api/blocked/add", JSONObject().put("name", raw))
            if (r == null) {
                onDone(false)
                return@launch
            }
            syncBlocked(r.optJSONArray("names").toStringList())
            r.optJSONObject("me")?.let { me = it.toMe() }
            onDone(true)
        }
    }

    fun removeBlocked(name: String) {
        viewModelScope.launch {
            val r = req("POST", "/api/blocked/remove", JSONObject().put("name", name)) ?: return@launch
            syncBlocked(r.optJSONArray("names").toStringList())
            r.optJSONObject("me")?.let { me = it.toMe() }
        }
    }

    fun withdraw(amount: String, card: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val a = amount.trim().toIntOrNull()
            if (a == null) {
                message = ctx.getString(R.string.err_generic, "bad_amount")
                onDone(false)
                return@launch
            }
            val r = req("POST", "/api/withdraw", JSONObject().put("amount", a).put("card", card))
            if (r == null) {
                onDone(false)
                return@launch
            }
            r.optJSONObject("me")?.let { me = it.toMe() }
            message = ctx.getString(R.string.withdraw_sent)
            loadWithdrawals()
            onDone(true)
        }
    }

    fun loadWithdrawals() {
        viewModelScope.launch {
            val r = req("GET", "/api/withdrawals", quiet = true) ?: return@launch
            withdrawals = r.optJSONArray("items").toWd()
        }
    }

    // ------------------------------------------------------------ admin
    fun adminLoadStats() {
        viewModelScope.launch {
            val r = req("GET", "/api/admin/stats") ?: return@launch
            val s = r.optJSONObject("stats") ?: return@launch
            adminStats = s.keys().asSequence().associateWith { s.optLong(it) }
        }
    }

    fun adminFind(idText: String) {
        viewModelScope.launch {
            val id = idText.trim().toLongOrNull() ?: run {
                message = ctx.getString(R.string.err_generic, "bad_id")
                return@launch
            }
            val r = req("GET", "/api/admin/user?id=$id") ?: return@launch
            adminUser = r.optJSONObject("user")?.toAdminUser()
        }
    }

    private fun adminPost(path: String, body: JSONObject) {
        viewModelScope.launch {
            val r = req("POST", path, body) ?: return@launch
            r.optJSONObject("user")?.let { adminUser = it.toAdminUser() }
        }
    }

    fun adminCoins(delta: Int) {
        val u = adminUser ?: return
        adminPost("/api/admin/coins", JSONObject().put("id", u.id).put("delta", delta))
    }

    fun adminVip(on: Boolean) {
        val u = adminUser ?: return
        adminPost("/api/admin/vip", JSONObject().put("id", u.id).put("vip", on))
    }

    fun adminBan(on: Boolean) {
        val u = adminUser ?: return
        adminPost("/api/admin/ban", JSONObject().put("id", u.id).put("banned", on))
    }

    fun adminLoadWd() {
        viewModelScope.launch {
            val r = req("GET", "/api/admin/withdrawals") ?: return@launch
            adminWd = r.optJSONArray("items").toWd()
        }
    }

    fun adminWdAction(id: Int, paid: Boolean) {
        viewModelScope.launch {
            req("POST", "/api/admin/withdrawal", JSONObject().put("id", id).put("action", if (paid) "paid" else "reject")) ?: return@launch
            adminLoadWd()
        }
    }

    private fun parseAdminChannels(a: JSONArray?): List<AdminChannel> =
        if (a == null) emptyList() else (0 until a.length()).map {
            val o = a.getJSONObject(it)
            AdminChannel(o.optInt("id"), o.optString("title"), o.optBoolean("enabled"))
        }

    fun adminLoadCh() {
        viewModelScope.launch {
            val r = req("GET", "/api/admin/channels") ?: return@launch
            adminCh = parseAdminChannels(r.optJSONArray("items"))
        }
    }

    fun adminChToggle(id: Int, enabled: Boolean) {
        viewModelScope.launch {
            val r = req("POST", "/api/admin/channel", JSONObject().put("id", id).put("enabled", enabled)) ?: return@launch
            adminCh = parseAdminChannels(r.optJSONArray("items"))
        }
    }

    fun adminChDelete(id: Int) {
        viewModelScope.launch {
            val r = req("POST", "/api/admin/channel", JSONObject().put("id", id).put("action", "delete")) ?: return@launch
            adminCh = parseAdminChannels(r.optJSONArray("items"))
        }
    }
}
