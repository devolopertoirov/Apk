package uz.safeapk.guard

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

sealed class PinResult {
    object Ok : PinResult()
    object Wrong : PinResult()
    class Locked(val seconds: Int) : PinResult()
}

/** PIN (PBKDF2 bilan xeshlanadi, ochiq saqlanmaydi) va qulf holati. */
object Lock {
    private const val ITER = 20_000
    private const val RELOCK_MS = 20_000L

    @Volatile
    private var lastActive = 0L

    fun hasPin(p: Prefs) = p.pinHash.isNotEmpty() && p.pinSalt.isNotEmpty()

    fun touch() {
        lastActive = System.currentTimeMillis()
    }

    /** Ilova ochilganda (yoki fondan 20 soniyadan keyin qaytganda) PIN kerakmi. */
    fun needsOpenAuth(ctx: Context): Boolean {
        val p = Prefs(ctx)
        return hasPin(p) && p.lockOpen && System.currentTimeMillis() - lastActive > RELOCK_MS
    }

    fun uninstallAllowed(p: Prefs) = System.currentTimeMillis() < p.uninstallUnlockUntil

    fun allowUninstallFor(p: Prefs, ms: Long) {
        p.uninstallUnlockUntil = System.currentTimeMillis() + ms
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, ITER, 256)).encoded

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    fun setPin(p: Prefs, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.pinSalt = hex(salt)
        p.pinHash = hex(hash(pin, salt))
        p.pinFails = 0
        p.pinLockUntil = 0L
    }

    fun clearPin(p: Prefs) {
        p.pinHash = ""
        p.pinSalt = ""
        p.pinFails = 0
        p.pinLockUntil = 0L
        p.useBiometric = false
        p.uninstallUnlockUntil = 0L
    }

    /** 5 ta xatodan keyin kutish: 30 s, 60 s, 120 s ... 10 daqiqagacha. */
    fun verify(p: Prefs, pin: String): PinResult {
        val now = System.currentTimeMillis()
        if (now < p.pinLockUntil) return PinResult.Locked(((p.pinLockUntil - now + 999) / 1000).toInt())
        val ok = MessageDigest.isEqual(hash(pin, unhex(p.pinSalt)), unhex(p.pinHash))
        if (ok) {
            p.pinFails = 0
            return PinResult.Ok
        }
        val f = p.pinFails + 1
        p.pinFails = f
        if (f >= 5) {
            val secs = minOf(30L shl minOf(f - 5, 5), 600L)
            p.pinLockUntil = now + secs * 1000L
            return PinResult.Locked(secs.toInt())
        }
        return PinResult.Wrong
    }
}

/** O‘rnatuvchi oynasidan oldin oxirgi ochilgan ilova (Telegramdan kelganini aniqlash uchun). Foydalanish statistikasi ruxsati kerak. */
object UsageSource {
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun isTelegram(pkg: String) =
        pkg.startsWith("org.telegram.") || pkg == "org.thunderdog.challegram" || pkg == "nekox.messenger" ||
            pkg.contains("nekogram") || pkg.startsWith("app.nicegram")

    @Suppress("DEPRECATION")
    fun lastApp(ctx: Context): String? {
        if (!hasAccess(ctx)) return null
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 180_000L, end) ?: return null
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType != UsageEvents.Event.MOVE_TO_FOREGROUND) continue
            val p = e.packageName ?: continue
            if (p == ctx.packageName || "packageinstaller" in p || p == "com.android.systemui" || p == "com.oplus.appdetail") continue
            last = p
        }
        return last
    }
}
