package uz.safeapk.guard

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import uz.safeapk.guard.analysis.AppScanner
import uz.safeapk.guard.analysis.Level

/** Yangi o‘rnatilgan ilovalarni topib, shubhali bo‘lsa bildirishnoma yuboradi. */
object NewAppChecker {
    private const val WORK = "new_app_check"
    private val lastNotified = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Real vaqt xizmati va 15 daqiqalik tekshiruv bir paket uchun ikki marta xabar bermasligi uchun. */
    private fun firstTime(pkg: String): Boolean {
        val now = System.currentTimeMillis()
        val prev = lastNotified.put(pkg, now)
        return prev == null || now - prev > 120_000L
    }

    /** Barcha yangi paketlarni tekshiradi (birinchi ishga tushishda faqat «asos» ro‘yxati olinadi). */
    suspend fun checkAll(ctx: Context) = withContext(Dispatchers.Default) {
        val prefs = Prefs(ctx)
        val current = AppScanner.userPackages(ctx)
        if (!prefs.baselineDone) {
            prefs.knownPackages = current
            prefs.baselineDone = true
            return@withContext
        }
        val fresh = current - prefs.knownPackages
        if (fresh.isNotEmpty()) {
            val active = AppScanner.loadActive(ctx)
            for (pkg in fresh) notifyIfRisky(ctx, pkg, active)
        }
        prefs.knownPackages = current
    }

    /** Bitta paketni (real vaqt xizmati yangi o‘rnatilganini bildirganda) tekshiradi. */
    suspend fun checkOne(ctx: Context, pkg: String) = withContext(Dispatchers.Default) {
        val prefs = Prefs(ctx)
        notifyIfRisky(ctx, pkg, AppScanner.loadActive(ctx))
        prefs.knownPackages = prefs.knownPackages + pkg
    }

    /** O‘rnatilgan ilova foydalanuvchining taqiqlar ro‘yxatiga tushsa, o‘chirishni taklif qiladi (ishonchli ro‘yxatdan ustun). */
    private fun listBlocked(ctx: Context, pkg: String): Boolean {
        if (pkg == ctx.packageName) return false
        val names = Prefs(ctx).blockedNames
        if (names.isEmpty()) return false
        val label = runCatching {
            val pm = ctx.packageManager
            pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
        }.getOrNull() ?: return false
        BlockList.labelMatches(names, label) ?: return false
        if (firstTime("bl:$pkg")) {
            Notifier.listBlocked(Lang.wrap(ctx), pkg, label)
            runCatching {
                ctx.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_DELETE, android.net.Uri.parse("package:$pkg"))
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        return true
    }

    private fun notifyIfRisky(ctx: Context, pkg: String, active: uz.safeapk.guard.analysis.ActiveSets) {
        if (listBlocked(ctx, pkg)) return
        if (pkg in Prefs(ctx).trusted) return
        val r = AppScanner.analyzeInstalled(ctx, pkg, active) ?: return
        if (r.result.level != Level.OK && firstTime(pkg)) Notifier.threat(Lang.wrap(ctx), pkg, r.label, r.result.level)
    }

    fun schedule(ctx: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (enabled) {
            wm.enqueueUniquePeriodicWork(
                WORK, ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<NewAppWorker>(15, TimeUnit.MINUTES).build(),
            )
        } else {
            wm.cancelUniqueWork(WORK)
        }
    }
}

class NewAppWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        NewAppChecker.checkAll(applicationContext)
        return Result.success()
    }
}
