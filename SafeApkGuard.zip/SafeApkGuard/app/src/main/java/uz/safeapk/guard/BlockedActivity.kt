package uz.safeapk.guard

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** O‘rnatish bekor qilingandan keyin chiqadigan oyna (xavfli fayl topilganda). */
class BlockedActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val label = intent.getStringExtra("label").orEmpty()
        val reasons = intent.getStringArrayExtra("reasons")?.toList().orEmpty()
        val pkg = intent.getStringExtra("pkg").orEmpty()
        val prefs = Prefs(this)
        val listBlock = intent.getBooleanExtra("listBlock", false)
        val group = intent.getStringExtra("group").orEmpty()
        setContent {
            GuardTheme {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                stringResource(R.string.blocked_title), color = RedBad,
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge,
                            )
                            Text(
                                if (group.isNotEmpty()) stringResource(R.string.blocked_group_body, label, group)
                                else stringResource(if (listBlock) R.string.blocked_list_body else R.string.blocked_body, label)
                            )
                            reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                            if (pkg.isNotEmpty()) {
                                OutlinedButton(onClick = {
                                    prefs.trusted = prefs.trusted + pkg
                                    finish()
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Text(stringResource(R.string.btn_trust))
                                }
                            }
                            Button(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) {
                                Text(stringResource(R.string.blocked_ok))
                            }
                        }
                    }
                }
            }
        }
    }
}
