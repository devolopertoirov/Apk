package uz.safeapk.guard

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = (ctx.applicationContext ?: ctx).getSharedPreferences("guard", Context.MODE_PRIVATE)

    var knownPackages: Set<String>
        get() = sp.getStringSet("known", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("known", v.toSet()).apply()

    var baselineDone: Boolean
        get() = sp.getBoolean("baseline", false)
        set(v) = sp.edit().putBoolean("baseline", v).apply()

    var realtime: Boolean
        get() = sp.getBoolean("realtime", false)
        set(v) = sp.edit().putBoolean("realtime", v).apply()

    var periodic: Boolean
        get() = sp.getBoolean("periodic", true)
        set(v) = sp.edit().putBoolean("periodic", v).apply()

    /** 0 = o‘chiq, 1 = faqat xavfli (standart), 2 = xavfli va shubhali, 3 = Telegramdan kelgan barcha APK */
    var blockMode: Int
        get() = sp.getInt("block_mode", 1)
        set(v) = sp.edit().putInt("block_mode", v).apply()

    var blockedCount: Int
        get() = sp.getInt("blocked_count", 0)
        set(v) = sp.edit().putInt("blocked_count", v).apply()

    /** 0 = tizim, 1 = yorug‘, 2 = qorong‘i */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** auto | uz | ru | en */
    var lang: String
        get() = sp.getString("lang", "auto") ?: "auto"
        set(v) = sp.edit().putString("lang", v).apply()

    /** Foydalanuvchi «ishonchli» deb belgilagan paketlar: ular xavfli deb ko‘rsatilmaydi va bloklanmaydi. */
    var trusted: Set<String>
        get() = sp.getStringSet("trusted", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("trusted", v.toSet()).apply()

    /** Guard Coin: sessiya kaliti (bot serveri bergan), bo‘sh bo‘lsa kirilmagan. */
    var token: String
        get() = sp.getString("gc_token", "") ?: ""
        set(v) = sp.edit().putString("gc_token", v).apply()

    /** Server manzili (Sozlamalardan); bo‘sh bo‘lsa Config.API_BASE ishlatiladi. */
    var apiBase: String
        get() = sp.getString("api_base", "") ?: ""
        set(v) = sp.edit().putString("api_base", v.trim()).apply()

    /** Do‘kon ekranini kuzatish diagnostikasi (oxirgi holat qisqa matn). */
    var storeDebug: String
        get() = sp.getString("store_debug", "") ?: ""
        set(v) = sp.edit().putString("store_debug", v).apply()

    var blocklistV13: Boolean
        get() = sp.getBoolean("blocklist_v13", false)
        set(v) = sp.edit().putBoolean("blocklist_v13", v).apply()

    /** ANDROID_ID bo‘lmasa, qurilma belgisi sifatida bir marta yaratiladigan tasodifiy qiymat. */
    val fallbackDevice: String
        get() = sp.getString("device_fb", null) ?: java.util.UUID.randomUUID().toString().also {
            sp.edit().putString("device_fb", it).apply()
        }

    /** Foydalanuvchi o‘rnatilishini taqiqlagan ilova nomlari (do‘kon va fayldan o‘rnatish ham bloklanadi). */
    var blockedNames: Set<String>
        get() = sp.getStringSet("blocked_names", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("blocked_names", v.toSet()).apply()

    /** Tekshiruv tarixi (JSON massiv, History.kt boshqaradi). */
    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) = sp.edit().putString("history", v).apply()

    var deletedFiles: Int
        get() = sp.getInt("deleted_files", 0)
        set(v) = sp.edit().putInt("deleted_files", v).apply()
}
