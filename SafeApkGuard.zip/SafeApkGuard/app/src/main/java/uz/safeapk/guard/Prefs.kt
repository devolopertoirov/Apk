package uz.safeapk.guard

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("guard", Context.MODE_PRIVATE)

    var knownPackages: Set<String>
        get() = sp.getStringSet("known", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("known", v.toSet()).apply()

    var baselineDone: Boolean
        get() = sp.getBoolean("baseline", false)
        set(v) = sp.edit().putBoolean("baseline", v).apply()

    var realtime: Boolean
        get() = sp.getBoolean("realtime", false)
        set(v) = sp.edit().putBoolean("realtime", v).apply()

    var periodic: Boolean
        get() = sp.getBoolean("periodic", true)
        set(v) = sp.edit().putBoolean("periodic", v).apply()
}
