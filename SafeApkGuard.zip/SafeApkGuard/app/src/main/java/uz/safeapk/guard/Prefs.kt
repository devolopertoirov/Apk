package uz.safeapk.guard

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = (ctx.applicationContext ?: ctx).getSharedPreferences("guard", Context.MODE_PRIVATE)

    var knownPackages: Set<String>
        get() = sp.getStringSet("known", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("known", v.toSet()).apply()

    var baselineDone: Boolean
        get() = sp.getBoolean("baseline", false)
        set(v) = sp.edit().putBoolean("baseline", v).apply()

    var realtime: Boolean
        get() = sp.getBoolean("realtime", false)
        set(v) = sp.edit().putBoolean("realtime", v).apply()

    var periodic: Boolean
        get() = sp.getBoolean("periodic", true)
        set(v) = sp.edit().putBoolean("periodic", v).apply()

    /** 0 = o‘chiq, 1 = faqat xavfli, 2 = xavfli va shubhali, 3 = Telegramdan kelgan barcha APK */
    var blockMode: Int
        get() = sp.getInt("block_mode", 2)
        set(v) = sp.edit().putInt("block_mode", v).apply()

    var blockedCount: Int
        get() = sp.getInt("blocked_count", 0)
        set(v) = sp.edit().putInt("blocked_count", v).apply()

    /** 0 = tizim, 1 = yorug‘, 2 = qorong‘i */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** auto | uz | ru | en */
    var lang: String
        get() = sp.getString("lang", "auto") ?: "auto"
        set(v) = sp.edit().putString("lang", v).apply()

    var deletedFiles: Int
        get() = sp.getInt("deleted_files", 0)
        set(v) = sp.edit().putInt("deleted_files", v).apply()
}
