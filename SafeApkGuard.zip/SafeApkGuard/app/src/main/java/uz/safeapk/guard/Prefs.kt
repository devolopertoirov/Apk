package uz.safeapk.guard

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = (ctx.applicationContext ?: ctx).getSharedPreferences("guard", Context.MODE_PRIVATE)

    var knownPackages: Set<String>
        get() = sp.getStringSet("known", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("known", v.toSet()).apply()

    var baselineDone: Boolean
        get() = sp.getBoolean("baseline", false)
        set(v) = sp.edit().putBoolean("baseline", v).apply()

    var realtime: Boolean
        get() = sp.getBoolean("realtime", false)
        set(v) = sp.edit().putBoolean("realtime", v).apply()

    var periodic: Boolean
        get() = sp.getBoolean("periodic", true)
        set(v) = sp.edit().putBoolean("periodic", v).apply()

    /** 0 = o‘chiq, 1 = faqat xavfli (standart), 2 = xavfli va shubhali, 3 = Telegramdan kelgan barcha APK */
    var blockMode: Int
        get() = sp.getInt("block_mode", 1)
        set(v) = sp.edit().putInt("block_mode", v).apply()

    var blockedCount: Int
        get() = sp.getInt("blocked_count", 0)
        set(v) = sp.edit().putInt("blocked_count", v).apply()

    /** 0 = tizim, 1 = yorug‘, 2 = qorong‘i */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** auto | uz | ru | en */
    var lang: String
        get() = sp.getString("lang", "auto") ?: "auto"
        set(v) = sp.edit().putString("lang", v).apply()

    /** Foydalanuvchi «ishonchli» deb belgilagan paketlar: ular xavfli deb ko‘rsatilmaydi va bloklanmaydi. */
    var trusted: Set<String>
        get() = sp.getStringSet("trusted", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("trusted", v.toSet()).apply()

    /** Do‘kon ekranini kuzatish diagnostikasi (oxirgi holat qisqa matn). */
    var storeDebug: String
        get() = sp.getString("store_debug", "") ?: ""
        set(v) = sp.edit().putString("store_debug", v).apply()

    /** Yoqilgan majburiy bloklash guruhlari (games, social, betting, video). */
    var enabledGroups: Set<String>
        get() = sp.getStringSet("groups", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("groups", v.toSet()).apply()

    /** O‘rnatilib qolgan va o‘chirilishi kerak bo‘lgan ilovalar nomi (o‘chirish oynasini o‘zi tasdiqlash uchun). */
    var pendingRemove: Set<String>
        get() = sp.getStringSet("pending_remove", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("pending_remove", v.toSet()).apply()

    // ---- PIN / barmoq izi qulfi (PIN faqat xeshlangan holda saqlanadi)
    var pinHash: String
        get() = sp.getString("pin_hash", "") ?: ""
        set(v) = sp.edit().putString("pin_hash", v).apply()
    var pinSalt: String
        get() = sp.getString("pin_salt", "") ?: ""
        set(v) = sp.edit().putString("pin_salt", v).apply()
    var pinFails: Int
        get() = sp.getInt("pin_fails", 0)
        set(v) = sp.edit().putInt("pin_fails", v).apply()
    var pinLockUntil: Long
        get() = sp.getLong("pin_lock_until", 0L)
        set(v) = sp.edit().putLong("pin_lock_until", v).apply()
    var lockOpen: Boolean
        get() = sp.getBoolean("lock_open", true)
        set(v) = sp.edit().putBoolean("lock_open", v).apply()
    var lockUninstall: Boolean
        get() = sp.getBoolean("lock_uninstall", true)
        set(v) = sp.edit().putBoolean("lock_uninstall", v).apply()
    var useBiometric: Boolean
        get() = sp.getBoolean("use_bio", false)
        set(v) = sp.edit().putBoolean("use_bio", v).apply()
    var uninstallUnlockUntil: Long
        get() = sp.getLong("uninstall_until", 0L)
        set(v) = sp.edit().putLong("uninstall_until", v).apply()

    /** Foydalanuvchi o‘rnatilishini taqiqlagan ilova nomlari (do‘kon va fayldan o‘rnatish ham bloklanadi). */
    var blockedNames: Set<String>
        get() = sp.getStringSet("blocked_names", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("blocked_names", v.toSet()).apply()

    /** Tekshiruv tarixi (JSON massiv, History.kt boshqaradi). */
    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) = sp.edit().putString("history", v).apply()

    var deletedFiles: Int
        get() = sp.getInt("deleted_files", 0)
        set(v) = sp.edit().putInt("deleted_files", v).apply()
}
