package uz.safeapk.guard.analysis

import androidx.annotation.StringRes
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import uz.safeapk.guard.R

enum class LinkKey(@StringRes val reason: Int, val serious: Boolean) {
    APK(R.string.l_apk, true),
    IP(R.string.l_ip, true),
    PUNY(R.string.l_puny, true),
    BRAND(R.string.l_brand, true),
    TLD(R.string.l_tld, false),
    SHORT(R.string.l_short, false),
}

data class LinkResult(
    val url: String, val host: String, val finalUrl: String, val keys: List<LinkKey>, val safe: Boolean,
) {
    val level: Level
        get() = when {
            safe -> Level.OK
            keys.any { it.serious } -> Level.BAD
            keys.isNotEmpty() -> Level.WARN
            else -> Level.OK
        }
}

/** Havola tekshiruvi (botdagi qoidalarning telefon varianti). */
object LinkAnalyzer {
    private val SAFE = listOf(
        "telegram.org", "t.me", "telegram.me", "telegram.dog", "telegra.ph", "google.com", "youtube.com",
        "youtu.be", "instagram.com", "facebook.com", "tiktok.com", "wikipedia.org", "whatsapp.com", "wa.me",
        "apple.com", "microsoft.com", "github.com", "yandex.ru", "yandex.uz", "gov.uz", "lex.uz", "soliq.uz",
        "click.uz", "payme.uz", "uzum.uz", "olx.uz", "uzcard.uz", "humocard.uz", "myid.uz", "paynet.uz",
        "kun.uz", "daryo.uz", "gazeta.uz",
    )
    private val SHORTENERS = listOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "cutt.ly", "is.gd", "rb.gy", "clck.ru", "vk.cc",
        "ow.ly", "shorturl.at", "tiny.cc", "rebrand.ly", "u.to", "qps.ru",
    )
    private val BAD_TLDS = setOf(
        "xyz", "top", "icu", "buzz", "cfd", "sbs", "cyou", "monster", "rest", "gq", "tk", "ml", "ga", "cf",
        "click", "loan", "zip",
    )
    private val BRANDS: Map<String, List<String>> = mapOf(
        "payme" to listOf("payme.uz"), "click" to listOf("click.uz"), "uzcard" to listOf("uzcard.uz"),
        "humo" to listOf("humocard.uz", "humo.uz"), "myid" to listOf("myid.uz"), "mygov" to listOf("my.gov.uz"),
        "soliq" to listOf("soliq.uz", "tax.uz"), "uzum" to listOf("uzum.uz", "uzum.com"), "olx" to listOf("olx.uz"),
        "paynet" to listOf("paynet.uz"), "kapitalbank" to listOf("kapitalbank.uz"),
        "xalqbank" to listOf("xb.uz", "xalqbank.uz"), "ipotekabank" to listOf("ipotekabank.uz"),
        "agrobank" to listOf("agrobank.uz"), "hamkorbank" to listOf("hamkorbank.uz"), "anorbank" to listOf("anorbank.uz"),
        "telegram" to listOf("telegram.org", "t.me", "telegram.me", "telegram.dog"),
        "instagram" to listOf("instagram.com", "cdninstagram.com"),
        "whatsapp" to listOf("whatsapp.com", "whatsapp.net", "wa.me"), "gov" to listOf("gov.uz"),
    )
    private val GENERIC = setOf("click", "gov")
    private val APK_EXT = listOf(".apk", ".xapk", ".apks", ".apkm")
    private val URL_RE = Regex("(?i)\\b(?:https?://)?(?:[a-z0-9-]+\\.)+[a-z]{2,}(?:/[^\\s]*)?")

    fun extractUrls(text: String): List<String> =
        URL_RE.findAll(text).map { it.value.trimEnd('.', ',', ')', '!', '?') }.distinct().take(5).toList()

    private fun parse(url: String): URI? =
        runCatching { URI(if ("://" in url) url else "http://$url") }.getOrNull()

    fun hostOf(url: String): String = parse(url)?.host?.lowercase()?.trimEnd('.').orEmpty()

    private fun hostIn(host: String, domains: List<String>) =
        domains.any { host == it || host.endsWith(".$it") }

    private fun deleet(s: String) = s.map {
        when (it) { '0' -> 'o'; '1' -> 'l'; '3' -> 'e'; '4' -> 'a'; '5' -> 's'; '@' -> 'a'; else -> it }
    }.joinToString("")

    /** a va b orasidagi tahrir masofasi 1 dan oshmaydimi. */
    private fun lev1(a0: String, b0: String): Boolean {
        var a = a0
        var b = b0
        if (a == b) return true
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        if (a.length == b.length) return a.indices.count { a[it] != b[it] } <= 1
        if (a.length > b.length) { val t = a; a = b; b = t }
        var i = 0
        while (i < a.length && a[i] == b[i]) i++
        return a.substring(i) == b.substring(i + 1)
    }

    private fun analyze(url: String): Pair<String, MutableList<LinkKey>> {
        val keys = mutableListOf<LinkKey>()
        val host = hostOf(url)
        if (host.isEmpty()) return host to keys
        val path = parse(url)?.path.orEmpty().lowercase()
        if (APK_EXT.any { path.endsWith(it) }) keys += LinkKey.APK
        if (Regex("[\\d.]+").matches(host) || ":" in host) keys += LinkKey.IP
        if ("xn--" in host) keys += LinkKey.PUNY
        val tokens = host.split('.', '-', '_')
        for ((brand, real) in BRANDS) {
            if (hostIn(host, real)) continue
            var hit = brand in tokens
            if (!hit && brand.length >= 5) {
                for (tok in tokens) {
                    val d = deleet(tok)
                    if ((brand in d && brand !in GENERIC) || (brand.length >= 6 && lev1(d, brand))) { hit = true; break }
                }
            }
            if (hit) { keys += LinkKey.BRAND; break }
        }
        if (host.substringAfterLast('.') in BAD_TLDS) keys += LinkKey.TLD
        return host to keys
    }

    /** Qisqartirilgan havolani ochadi. Faqat SHORTENERS ro‘yxatidagi saytlarga so‘rov yuboriladi. */
    private suspend fun expand(url: String): String? = withContext(Dispatchers.IO) {
        var cur = (if ("://" in url) url else "https://$url").replaceFirst("http://", "https://")
        try {
            repeat(5) {
                if (!hostIn(hostOf(cur), SHORTENERS)) return@withContext cur
                val c = URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                try {
                    val code = c.responseCode
                    val loc = c.getHeaderField("Location")
                    if (code in 300..399 && loc != null) {
                        cur = URL(URL(cur), loc).toString()
                        if (hostIn(hostOf(cur), SHORTENERS)) cur = cur.replaceFirst("http://", "https://")
                    } else {
                        return@withContext cur
                    }
                } finally {
                    c.disconnect()
                }
            }
            cur
        } catch (e: Exception) {
            null
        }
    }

    suspend fun inspect(url: String): LinkResult? {
        var (host, keys) = analyze(url)
        if (host.isEmpty()) return null
        var final = url
        var expanded = false
        if (hostIn(host, SHORTENERS)) {
            val exp = expand(url)
            if (exp != null && exp != url) {
                final = exp
                expanded = true
                val r = analyze(exp)
                host = r.first.ifEmpty { host }
                keys = r.second
            }
        }
        val safe = hostIn(host, SAFE)
        if (!safe && expanded && keys.any { it.serious }) keys.add(LinkKey.SHORT)
        return LinkResult(url, host, final, keys, safe)
    }
}
