package uz.safeapk.guard.analysis

import androidx.annotation.StringRes
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import uz.safeapk.guard.R

enum class LinkKey(@StringRes val reason: Int, val serious: Boolean) {
    APK(R.string.l_apk, true),
    IP(R.string.l_ip, true),
    PUNY(R.string.l_puny, true),
    BRAND(R.string.l_brand, true),
    TLD(R.string.l_tld, false),
    SHORT(R.string.l_short, false),
    UNVERIFIED(R.string.l_unverified, false),
}

data class LinkResult(
    val url: String, val host: String, val finalUrl: String, val keys: List<LinkKey>, val safe: Boolean,
) {
    val level: Level
        get() = when {
            keys.any { it.serious } -> Level.BAD
            keys.isNotEmpty() -> Level.WARN
            else -> Level.OK
        }
}

/** Havola tekshiruvi (botdagi qoidalarning telefon varianti). */
object LinkAnalyzer {
    private val SAFE = listOf(
        "telegram.org", "t.me", "telegram.me", "telegram.dog", "telegra.ph", "google.com", "youtube.com",
        "youtu.be", "instagram.com", "facebook.com", "tiktok.com", "wikipedia.org", "whatsapp.com", "wa.me",
        "apple.com", "microsoft.com", "github.com", "yandex.ru", "yandex.uz", "gov.uz", "lex.uz", "soliq.uz",
        "click.uz", "payme.uz", "uzum.uz", "olx.uz", "uzcard.uz", "humocard.uz", "myid.uz", "paynet.uz",
        "kun.uz", "daryo.uz", "gazeta.uz",
    )
    private val SHORTENERS = listOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "cutt.ly", "is.gd", "rb.gy", "clck.ru", "vk.cc",
        "ow.ly", "shorturl.at", "tiny.cc", "rebrand.ly", "u.to", "qps.ru",
    )
    private val BAD_TLDS = setOf(
        "xyz", "top", "icu", "buzz", "cfd", "sbs", "cyou", "monster", "rest", "gq", "tk", "ml", "ga", "cf",
        "click", "loan", "zip",
    )
    private val BRANDS: Map<String, List<String>> = mapOf(
        "payme" to listOf("payme.uz"), "click" to listOf("click.uz"), "uzcard" to listOf("uzcard.uz"),
        "humo" to listOf("humocard.uz", "humo.uz"), "myid" to listOf("myid.uz"), "mygov" to listOf("my.gov.uz"),
        "soliq" to listOf("soliq.uz", "tax.uz"), "uzum" to listOf("uzum.uz", "uzum.com"), "olx" to listOf("olx.uz", "olx.pl", "olx.kz", "olx.ua", "olx.ro", "olx.bg", "olx.pt", "olx.com", "olx.com.br", "olx.in"),
        "paynet" to listOf("paynet.uz"), "kapitalbank" to listOf("kapitalbank.uz"),
        "xalqbank" to listOf("xb.uz", "xalqbank.uz"), "ipotekabank" to listOf("ipotekabank.uz"),
        "agrobank" to listOf("agrobank.uz"), "hamkorbank" to listOf("hamkorbank.uz"), "anorbank" to listOf("anorbank.uz"),
        "telegram" to listOf("telegram.org", "t.me", "telegram.me", "telegram.dog"),
        "instagram" to listOf("instagram.com", "cdninstagram.com"),
        "whatsapp" to listOf("whatsapp.com", "whatsapp.net", "wa.me"), "gov" to listOf("gov.uz"),
    )
    private val GENERIC = setOf("click", "gov")
    /** Brend nomiga qo‘shilganda shubhali bo‘ladigan so‘zlar: paymeuz, instagram-login ... («payment» kabilar hisobga olinmaydi). */
    private val BRAND_WORDS = setOf(
        "uz", "bank", "pay", "online", "app", "apk", "official", "support", "verify", "login", "secure", "my",
        "tolov", "pul", "service", "xizmat", "card", "cabinet", "kabinet", "new", "web", "mobile", "bot", "help",
        "info", "free", "bonus",
    )
    /** Matndagi fayl nomlari (setup.apk, hujjat.pdf) havola emas. */
    private val FILE_EXT = setOf(
        "apk", "xapk", "apks", "apkm", "zip", "rar", "7z", "pdf", "doc", "docx", "xls", "xlsx", "jpg", "jpeg",
        "png", "gif", "mp3", "mp4", "txt", "exe", "json", "html", "htm",
    )
    private val IPV4 = Regex("(?:\\d{1,3}\\.){3}\\d{1,3}")
    private val APK_EXT = listOf(".apk", ".xapk", ".apks", ".apkm")
    // Unicode harflar (kirill/lotin lookalike domenlar) va IPv4 manzillar ham ushlanadi
    private val URL_RE = Regex(
        "(?i)(?:https?://(?:[^\\s/@]+@)?)?(?:(?:[\\p{L}\\p{N}-]+\\.)+\\p{L}{2,}|(?:\\d{1,3}\\.){3}\\d{1,3})(?::\\d+)?(?:/[^\\s]*)?"
    )

    private fun hostPart(s: String): String {
        val noScheme = s.substringAfter("://", s)
        return noScheme.takeWhile { it != '/' && it != '?' && it != '#' && it != ':' }
    }

    fun extractUrls(text: String): List<String> =
        URL_RE.findAll(text).filter { m ->
            val s = m.value
            val before = if (m.range.first > 0) text[m.range.first - 1] else ' '
            val after = if (m.range.last + 1 < text.length) text[m.range.last + 1] else ' '
            val hasScheme = "://" in s
            if (!hasScheme && (before == '@' || after == '@')) return@filter false // e-pochta manzili
            val host = hostPart(s)
            val tld = host.substringAfterLast('.').lowercase()
            if (!hasScheme && tld in FILE_EXT) return@filter false // fayl nomi
            if (!hasScheme && '/' !in s && IPV4.matches(host)) return@filter false // oddiy raqamlar
            true
        }.map { it.value.trimEnd('.', ',', ')', '!', '?', ';', ':') }.distinct().take(5).toList()

    /** Domenni ASCII (punycode) ko‘rinishiga o‘tkazadi: «раyme.uz» kabi lookalike domenlar xn-- bilan ochiladi. */
    private fun asciiUrl(url: String): String {
        val full = if ("://" in url) url else "http://$url"
        val schemeEnd = full.indexOf("://") + 3
        var end = schemeEnd
        while (end < full.length && full[end] != '/' && full[end] != '?' && full[end] != '#') end++
        val authority = full.substring(schemeEnd, end)
        val at = authority.lastIndexOf('@')
        val userinfo = if (at >= 0) authority.substring(0, at + 1) else ""
        var hostPort = authority.substring(at + 1)
        var port = ""
        val colon = hostPort.lastIndexOf(':')
        if (colon >= 0 && !hostPort.endsWith("]")) {
            port = hostPort.substring(colon)
            hostPort = hostPort.substring(0, colon)
        }
        val ascii = runCatching { java.net.IDN.toASCII(hostPort, java.net.IDN.ALLOW_UNASSIGNED) }.getOrDefault(hostPort)
        return full.substring(0, schemeEnd) + userinfo + ascii + port + full.substring(end)
    }

    private fun parse(url: String): URI? =
        runCatching { URI(asciiUrl(url)) }.getOrNull()

    fun hostOf(url: String): String = parse(url)?.host?.lowercase()?.trimEnd('.').orEmpty()

    private fun hostIn(host: String, domains: List<String>) =
        domains.any { host == it || host.endsWith(".$it") }

    private fun deleet(s: String) = s.map {
        when (it) { '0' -> 'o'; '1' -> 'l'; '3' -> 'e'; '4' -> 'a'; '5' -> 's'; '@' -> 'a'; else -> it }
    }.joinToString("")

    /** a va b orasidagi tahrir masofasi 1 dan oshmaydimi. */
    private fun lev1(a0: String, b0: String): Boolean {
        var a = a0
        var b = b0
        if (a == b) return true
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        if (a.length == b.length) return a.indices.count { a[it] != b[it] } <= 1
        if (a.length > b.length) { val t = a; a = b; b = t }
        var i = 0
        while (i < a.length && a[i] == b[i]) i++
        return a.substring(i) == b.substring(i + 1)
    }

    /**
     * Token brend nomiga o‘xshashmi? Avval «brend in token» (payme ⊂ payment) tekshirilardi va noto‘g‘ri
     * ogohlantirish berardi; endi faqat aniq mos kelish, 1 harfli farq yoki brend + «uz/bank/login...» qabul qilinadi.
     */
    private fun brandHit(brand: String, tok: String, uzCtx: Boolean): Boolean {
        val d = deleet(tok)
        if (d == brand) return brand !in GENERIC || uzCtx // «gov.uk», «click.com» kabilar zararsiz
        if (brand in GENERIC) return false
        if (brand.length >= 5 && lev1(d, brand)) return true
        if (d.startsWith(brand) && d.substring(brand.length) in BRAND_WORDS) return true
        if (d.endsWith(brand) && d.substring(0, d.length - brand.length) in BRAND_WORDS) return true
        return false
    }

    private fun analyze(url: String): Pair<String, MutableList<LinkKey>> {
        val keys = mutableListOf<LinkKey>()
        val host = hostOf(url)
        if (host.isEmpty()) return host to keys
        val path = parse(url)?.path.orEmpty().lowercase()
        if (APK_EXT.any { path.endsWith(it) }) keys += LinkKey.APK
        if (Regex("[\\d.]+").matches(host) || ":" in host) keys += LinkKey.IP
        if ("xn--" in host) keys += LinkKey.PUNY
        // «https://payme.uz@evil.com» hiylasi: @ dan oldingi qism haqiqiy domen kabi ko‘rinadi
        if (parse(url)?.userInfo?.contains('.') == true) keys += LinkKey.BRAND
        val tokens = host.split('.', '-', '_')
        val uzCtx = "uz" in tokens || host.substringAfterLast('.') in BAD_TLDS
        for ((brand, real) in BRANDS) {
            if (hostIn(host, real)) continue
            if (tokens.any { brandHit(brand, it, uzCtx) }) { keys += LinkKey.BRAND; break }
        }
        if (host.substringAfterLast('.') in BAD_TLDS) keys += LinkKey.TLD
        return host to keys
    }

    /** Qisqartirilgan havolani ochadi. Faqat SHORTENERS ro‘yxatidagi saytlarga so‘rov yuboriladi. */
    private suspend fun expand(url: String): String? = withContext(Dispatchers.IO) {
        var cur = (if ("://" in url) url else "https://$url").replaceFirst("http://", "https://")
        try {
            repeat(5) {
                if (!hostIn(hostOf(cur), SHORTENERS)) return@withContext cur
                val c = URL(cur).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                try {
                    val code = c.responseCode
                    val loc = c.getHeaderField("Location")
                    if (code in 300..399 && loc != null) {
                        cur = URL(URL(cur), loc).toString()
                        if (hostIn(hostOf(cur), SHORTENERS)) cur = cur.replaceFirst("http://", "https://")
                    } else {
                        return@withContext cur
                    }
                } finally {
                    c.disconnect()
                }
            }
            cur
        } catch (e: Exception) {
            null
        }
    }

    suspend fun inspect(url: String): LinkResult? {
        var (host, keys) = analyze(url)
        if (host.isEmpty()) return null
        var final = url
        var expanded = false
        if (hostIn(host, SHORTENERS)) {
            val exp = expand(url)
            if (exp != null && exp != url) {
                final = exp
                expanded = true
                val r = analyze(exp)
                host = r.first.ifEmpty { host }
                keys = r.second
            }
        }
        // Qisqartirilgan havola ochilmadi (offline/xato) — «xavfsiz» deb bo‘lmaydi
        if (hostIn(host, SHORTENERS)) keys.add(LinkKey.UNVERIFIED)
        val safe = hostIn(host, SAFE)
        // Ishonchli domen ham APK, IP yoki soxta (punycode) belgisini yashira olmaydi
        if (safe) keys.retainAll { it == LinkKey.APK || it == LinkKey.IP || it == LinkKey.PUNY }
        if (!safe && expanded && keys.any { it.serious }) keys.add(LinkKey.SHORT)
        return LinkResult(url, host, final, keys, safe)
    }
}
